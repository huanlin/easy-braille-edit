using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using Huanlin.Braille;
using Huanlin.Helpers;


public partial class BrlRefmtResult : System.Web.UI.Page
{
    private BrailleProcessor m_Processor;
    private BrailleDocument m_Doc;
    private StringBuilder m_ErrChars;

    private void CreateObjects()
    {
        ChineseWordConverter chtCvt;
        EnglishWordConverter engCvt;

        string path = Server.MapPath(@"~\");

        m_Processor = (BrailleProcessor)Cache["Processor"];
        if (m_Processor == null)
        {
            m_Processor = new BrailleProcessor(false);
            Cache.Insert("Processor", m_Processor);

            chtCvt = (ChineseWordConverter)Cache["ChtCvt"];
            if (chtCvt == null)
            {
                chtCvt = new ChineseWordConverter(path + "BrailleTableCht.xml");
                Cache.Insert("ChtCvt", chtCvt);
            }

            engCvt = (EnglishWordConverter)Cache["EngCvt"];
            if (engCvt == null)
            {
                engCvt = new EnglishWordConverter(path + "BrailleTableEng.xml");
                Cache.Insert("EngCvt", engCvt);
            }

            m_Processor.AddWordConverter(chtCvt);
            m_Processor.AddWordConverter(engCvt);
        }

        m_Doc = (BrailleDocument)Session["Doc"];
        if (m_Doc == null)
        {
            m_Doc = new BrailleDocument(m_Processor, Huanlin.Braille.BrailleConst.DefaultCellsPerLine);
            Session["Doc"] = m_Doc;
        }

    }

    void BrailleProcesser_ConvertionFailed(object sender, ConvertionFailedEventArgs args)
    {
        m_ErrChars.Append("�� ");
        m_ErrChars.Append(args.LineNumber.ToString());
        m_ErrChars.Append(" ��G");
        m_ErrChars.Append(args.InvalidChar);
        m_ErrChars.Append("\r\n");
    }
    
    protected void Page_Load(object sender, EventArgs e)
    {
        CreateObjects();

        int cellsPerLine = Convert.ToInt32(Request.Form["txtCellsPerLine"]);
        string lines = Request.Form["txtLines"];

        if (String.IsNullOrEmpty(lines))
        {
            Response.Redirect("~/BrlRefmt.aspx");
            return;
        }

        m_ErrChars = new StringBuilder();
        txtResult.Text = "���L�k�ഫ���r���A�Ч󥿫�A�դ@���C\r\n�L�k�ഫ���r���p�U�G\r\n\r\n";

        // �d�I�ഫ���Ѫ��ƥ�
        ConvertionFailedEventHandler handler = new ConvertionFailedEventHandler(BrailleProcesser_ConvertionFailed);
        m_Processor.ConvertionFailed += handler;


        try
        {
            // �����ഫ�P�_�r
            m_Doc.CellsPerLine = cellsPerLine;
            m_Doc.Load(lines);
            m_Doc.FormatDocument();

            // ��X���G
            if (m_ErrChars.Length > 0)
            {
                txtResult.Text += m_ErrChars.ToString();
            }
            else
            {
                txtResult.Text = m_Doc.ToString();
                txtResult.ForeColor = System.Drawing.Color.Black;
            }
        }
        finally
        {
            // ���P�ƥ��d�I
            m_Processor.ConvertionFailed -= handler;
        }
    }
}
