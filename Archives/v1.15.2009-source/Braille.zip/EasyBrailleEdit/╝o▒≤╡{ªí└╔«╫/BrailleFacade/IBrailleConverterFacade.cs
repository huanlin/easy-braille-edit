﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BrailleFacadeIntf
{
	public interface IBrailleConverterFacade
	{
		/// <summary>
		/// 將明眼字轉換成點字並儲存於暫存檔案。
		/// </summary>
		/// <param name="content">明眼字串。</param>
		/// <param name="cellsPerLine">每列最大方數。</param>
		/// <returns>暫存檔案的完整檔名。</returns>
		void ConvertToTempFile(StringBuilder content, int cellsPerLine);
	}
}
