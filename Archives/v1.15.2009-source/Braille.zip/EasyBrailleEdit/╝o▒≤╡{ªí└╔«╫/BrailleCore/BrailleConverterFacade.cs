﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using BrailleFacadeIntf;
using Huanlin.Braille;

namespace BrailleFacade
{
	public class BrailleConverterFacade : MarshalByRefObject, IBrailleConverterFacade
	{
		private delegate void ConvertDelegate(StringBuilder content, int cellsPerLine);

		public BrailleConverterFacade()
		{
		}

		public void ConvertToTempFile(StringBuilder content, int cellsPerLine) 
		{
			ConvertDelegate dele = new ConvertDelegate(this.DoConvert);
			IAsyncResult ar = dele.BeginInvoke(content, cellsPerLine, null, null);
			dele.EndInvoke(ar);

			//return fname;
		}

		public void DoConvert(StringBuilder content, int cellsPerLine) 
		{
			BrailleDocument m_Doc;
			BrailleProcessor m_Processor;

			m_Processor = new BrailleProcessor();
			m_Doc = new BrailleDocument(m_Processor);


			m_Doc.CellsPerLine = cellsPerLine;
			m_Doc.LoadAndConvert(content);

//			string fname = Path.GetTempPath() + "ebetemp_" + DateTime.Now.ToString("yyyyMMddhhmmssff") + ".btx";
//			m_Doc.Save(fname);

//			m_Doc.Clear();
//			m_Doc = null;
		}
	}
}
