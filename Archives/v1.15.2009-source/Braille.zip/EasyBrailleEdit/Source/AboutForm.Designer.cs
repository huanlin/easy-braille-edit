﻿namespace EasyBrailleEdit
{
    partial class AboutForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.btnClose = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.lblDateLimit = new System.Windows.Forms.Label();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.lblUserReg = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.lblVesion = new System.Windows.Forms.Label();
			this.btnRegister = new System.Windows.Forms.Button();
			this.linkLabel1 = new System.Windows.Forms.LinkLabel();
			this.panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// btnClose
			// 
			this.btnClose.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.btnClose.Location = new System.Drawing.Point(355, 215);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(91, 33);
			this.btnClose.TabIndex = 2;
			this.btnClose.Text = "關閉(&X)";
			this.btnClose.UseVisualStyleBackColor = true;
			// 
			// panel1
			// 
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.panel1.Controls.Add(this.linkLabel1);
			this.panel1.Controls.Add(this.lblDateLimit);
			this.panel1.Controls.Add(this.pictureBox1);
			this.panel1.Controls.Add(this.lblUserReg);
			this.panel1.Controls.Add(this.label1);
			this.panel1.Controls.Add(this.lblVesion);
			this.panel1.Location = new System.Drawing.Point(15, 12);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(431, 189);
			this.panel1.TabIndex = 0;
			// 
			// lblDateLimit
			// 
			this.lblDateLimit.AutoSize = true;
			this.lblDateLimit.Location = new System.Drawing.Point(15, 158);
			this.lblDateLimit.Name = "lblDateLimit";
			this.lblDateLimit.Size = new System.Drawing.Size(80, 15);
			this.lblDateLimit.TabIndex = 7;
			this.lblDateLimit.Text = "lblDateLimit";
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = global::EasyBrailleEdit.Properties.Resources.owl2;
			this.pictureBox1.Location = new System.Drawing.Point(3, 5);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(54, 50);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pictureBox1.TabIndex = 6;
			this.pictureBox1.TabStop = false;
			// 
			// lblUserReg
			// 
			this.lblUserReg.AutoSize = true;
			this.lblUserReg.Location = new System.Drawing.Point(15, 132);
			this.lblUserReg.Name = "lblUserReg";
			this.lblUserReg.Size = new System.Drawing.Size(70, 15);
			this.lblUserReg.TabIndex = 5;
			this.lblUserReg.Text = "lblUserReg";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(64, 40);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(257, 30);
			this.label1.TabIndex = 3;
			this.label1.Text = "原點工作室 版權所有\r\nCopyright (c) 2007-2008 InnoObject Studio";
			// 
			// lblVesion
			// 
			this.lblVesion.AutoSize = true;
			this.lblVesion.Location = new System.Drawing.Point(64, 16);
			this.lblVesion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.lblVesion.Name = "lblVesion";
			this.lblVesion.Size = new System.Drawing.Size(153, 15);
			this.lblVesion.TabIndex = 2;
			this.lblVesion.Text = "易點雙視 1.0.2008.0103";
			// 
			// btnRegister
			// 
			this.btnRegister.Location = new System.Drawing.Point(15, 215);
			this.btnRegister.Name = "btnRegister";
			this.btnRegister.Size = new System.Drawing.Size(121, 33);
			this.btnRegister.TabIndex = 1;
			this.btnRegister.Text = "註冊(&R)";
			this.btnRegister.UseVisualStyleBackColor = true;
			this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
			// 
			// linkLabel1
			// 
			this.linkLabel1.AutoSize = true;
			this.linkLabel1.Location = new System.Drawing.Point(64, 80);
			this.linkLabel1.Name = "linkLabel1";
			this.linkLabel1.Size = new System.Drawing.Size(168, 15);
			this.linkLabel1.TabIndex = 8;
			this.linkLabel1.TabStop = true;
			this.linkLabel1.Text = "http://innoobj.blogspot.com/";
			this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
			// 
			// AboutForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.CancelButton = this.btnClose;
			this.ClientSize = new System.Drawing.Size(458, 260);
			this.Controls.Add(this.btnRegister);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.btnClose);
			this.Font = new System.Drawing.Font("PMingLiU", 11F);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Margin = new System.Windows.Forms.Padding(4);
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "AboutForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "關於 EasyBrailleEdit";
			this.Load += new System.EventHandler(this.AboutForm_Load);
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label lblVesion;
        private System.Windows.Forms.Label lblUserReg;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Button btnRegister;
		private System.Windows.Forms.Label lblDateLimit;
		private System.Windows.Forms.LinkLabel linkLabel1;
    }
}