﻿namespace EasyBrailleEdit
{
	partial class RemindTrialForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panel1 = new System.Windows.Forms.Panel();
			this.btnNo = new System.Windows.Forms.Button();
			this.chkDontAskMeAgain = new System.Windows.Forms.CheckBox();
			this.panel2 = new System.Windows.Forms.Panel();
			this.label1 = new System.Windows.Forms.Label();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.panel1.Controls.Add(this.btnNo);
			this.panel1.Controls.Add(this.chkDontAskMeAgain);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel1.Location = new System.Drawing.Point(0, 109);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(404, 56);
			this.panel1.TabIndex = 1;
			// 
			// btnNo
			// 
			this.btnNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnNo.DialogResult = System.Windows.Forms.DialogResult.No;
			this.btnNo.Location = new System.Drawing.Point(298, 9);
			this.btnNo.Name = "btnNo";
			this.btnNo.Size = new System.Drawing.Size(92, 33);
			this.btnNo.TabIndex = 2;
			this.btnNo.Text = "關閉(&X)";
			this.btnNo.UseVisualStyleBackColor = true;
			// 
			// chkDontAskMeAgain
			// 
			this.chkDontAskMeAgain.AutoSize = true;
			this.chkDontAskMeAgain.Location = new System.Drawing.Point(10, 16);
			this.chkDontAskMeAgain.Name = "chkDontAskMeAgain";
			this.chkDontAskMeAgain.Size = new System.Drawing.Size(101, 19);
			this.chkDontAskMeAgain.TabIndex = 1;
			this.chkDontAskMeAgain.Text = "別再提醒我";
			this.chkDontAskMeAgain.UseVisualStyleBackColor = true;
			// 
			// panel2
			// 
			this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.panel2.Controls.Add(this.label1);
			this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel2.Location = new System.Drawing.Point(0, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(404, 109);
			this.panel2.TabIndex = 2;
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("MingLiU", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
			this.label1.ForeColor = System.Drawing.Color.Maroon;
			this.label1.Location = new System.Drawing.Point(34, 28);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(338, 51);
			this.label1.TabIndex = 1;
			this.label1.Text = "試用版有一些功能限制，包括：列印時會在頁尾加印「試用版」字樣，列印的頁數限制為 %1 頁，而且有試用期限。\r\n";
			// 
			// RemindTrialForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(404, 165);
			this.ControlBox = false;
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.Font = new System.Drawing.Font("PMingLiU", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
			this.Margin = new System.Windows.Forms.Padding(4);
			this.Name = "RemindTrialForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "注意! 您現在使用的是試用版";
			this.Load += new System.EventHandler(this.RemindTrialForm_Load);
			this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.AskRegForm_FormClosed);
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.panel2.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Button btnNo;
		private System.Windows.Forms.CheckBox chkDontAskMeAgain;
		private System.Windows.Forms.Label label1;

	}
}