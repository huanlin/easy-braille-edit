﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Diagnostics;

namespace EasyBrailleEdit
{
    public partial class AboutForm : Form
    {
        public AboutForm()
        {
            InitializeComponent();
        }

        private void AboutForm_Load(object sender, EventArgs e)
        {
            lblUserReg.Text = "";
			lblDateLimit.Text = "使用期限: 無";
			btnRegister.Visible = false;

			string fileVer = " v" + Assembly.GetExecutingAssembly().GetName().Version.ToString();

			if (AppGlobals.UserRegInfo != null)
			{
				lblVesion.Text = "易點雙視 " + AppGlobals.UserRegInfo.LongVersionName + fileVer;
				lblUserReg.Text = "註冊用戶: " + AppGlobals.UserRegInfo.CustomerName;
				if (AppGlobals.UserRegInfo.ExpiredDate.Year < 2300) 
				{
					lblDateLimit.Text = "使用期限: " + AppGlobals.UserRegInfo.ExpiredDate.ToString("yyyy-MM-dd");
				}
				if (AppGlobals.UserRegInfo.VersionName.StartsWith("TRI"))
				{
					btnRegister.Text = "重新註冊(&R)";
					btnRegister.Visible = true;
				}
			}
			else
			{
				lblVesion.Text = "易點雙視 " + fileVer;
				lblUserReg.Text = "您尚未註冊!"; 
				btnRegister.Visible = true;
			}

#if DEBUG
			lblVesion.Text = lblVesion.Text + " （除錯版）";
#endif
        }

		private void btnRegister_Click(object sender, EventArgs e)
		{
			RegForm fm = new RegForm();
			fm.ShowDialog();
		}

		private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			try 
			{
				Process.Start(linkLabel1.Text);
			}
			catch 
			{
				Process process = new Process();
				process.StartInfo.FileName = "iexplore.exe";
				process.StartInfo.Arguments = linkLabel1.Text;
				process.StartInfo.UseShellExecute = true;
				process.Start();
			}
		}
    }
}