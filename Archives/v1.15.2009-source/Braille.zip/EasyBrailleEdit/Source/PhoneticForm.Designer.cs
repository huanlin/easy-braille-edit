﻿namespace EasyBrailleEdit
{
	partial class PhoneticForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PhoneticForm));
			this.toolStrip1 = new System.Windows.Forms.ToolStrip();
			this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
			this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
			this.btnV1 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton14 = new System.Windows.Forms.ToolStripButton();
			this.btnV2 = new System.Windows.Forms.ToolStripButton();
			this.btnV3 = new System.Windows.Forms.ToolStripButton();
			this.btnV4 = new System.Windows.Forms.ToolStripButton();
			this.btnV5 = new System.Windows.Forms.ToolStripButton();
			this.btnV6 = new System.Windows.Forms.ToolStripButton();
			this.btnV7 = new System.Windows.Forms.ToolStripButton();
			this.btnV8 = new System.Windows.Forms.ToolStripButton();
			this.btnV9 = new System.Windows.Forms.ToolStripButton();
			this.btnV10 = new System.Windows.Forms.ToolStripButton();
			this.btnV11 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton9 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton8 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton59 = new System.Windows.Forms.ToolStripButton();
			this.toolStrip4 = new System.Windows.Forms.ToolStrip();
			this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
			this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
			this.toolStripButton60 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton61 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton62 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton63 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton64 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton65 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton66 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton67 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton68 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton69 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton70 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton11 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton71 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton72 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton12 = new System.Windows.Forms.ToolStripButton();
			this.toolStrip2 = new System.Windows.Forms.ToolStrip();
			this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
			this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
			this.toolStripButton38 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton37 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton36 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton35 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton34 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton33 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton32 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton31 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton30 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton13 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton29 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton28 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton27 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton26 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton25 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton24 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton23 = new System.Windows.Forms.ToolStripButton();
			this.toolStrip3 = new System.Windows.Forms.ToolStrip();
			this.toolStripLabel4 = new System.Windows.Forms.ToolStripLabel();
			this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
			this.toolStripButton22 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton90 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton91 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton92 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton93 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton94 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton95 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton96 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton97 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton98 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton99 = new System.Windows.Forms.ToolStripButton();
			this.toolStrip5 = new System.Windows.Forms.ToolStrip();
			this.toolStripLabel5 = new System.Windows.Forms.ToolStripLabel();
			this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
			this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton10 = new System.Windows.Forms.ToolStripButton();
			this.btnOk = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.txtPhonetic = new System.Windows.Forms.TextBox();
			this.btnCancel = new System.Windows.Forms.Button();
			this.label2 = new System.Windows.Forms.Label();
			this.chkAddBracket = new System.Windows.Forms.CheckBox();
			this.toolStrip1.SuspendLayout();
			this.toolStrip4.SuspendLayout();
			this.toolStrip2.SuspendLayout();
			this.toolStrip3.SuspendLayout();
			this.toolStrip5.SuspendLayout();
			this.SuspendLayout();
			// 
			// toolStrip1
			// 
			this.toolStrip1.Font = new System.Drawing.Font("Arial Unicode MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
			this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel1,
            this.toolStripSeparator1,
            this.btnV1,
            this.toolStripButton14,
            this.btnV2,
            this.btnV3,
            this.btnV4,
            this.btnV5,
            this.btnV6,
            this.btnV7,
            this.btnV8,
            this.btnV9,
            this.btnV10,
            this.btnV11,
            this.toolStripButton9,
            this.toolStripButton7,
            this.toolStripButton8,
            this.toolStripButton59});
			this.toolStrip1.Location = new System.Drawing.Point(0, 0);
			this.toolStrip1.Name = "toolStrip1";
			this.toolStrip1.Size = new System.Drawing.Size(656, 40);
			this.toolStrip1.TabIndex = 1;
			this.toolStrip1.Text = "toolStrip1";
			// 
			// toolStripLabel1
			// 
			this.toolStripLabel1.Font = new System.Drawing.Font("PMingLiU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
			this.toolStripLabel1.Name = "toolStripLabel1";
			this.toolStripLabel1.Size = new System.Drawing.Size(42, 37);
			this.toolStripLabel1.Text = "母音";
			// 
			// toolStripSeparator1
			// 
			this.toolStripSeparator1.Name = "toolStripSeparator1";
			this.toolStripSeparator1.Size = new System.Drawing.Size(6, 40);
			// 
			// btnV1
			// 
			this.btnV1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.btnV1.Image = ((System.Drawing.Image)(resources.GetObject("btnV1.Image")));
			this.btnV1.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnV1.Name = "btnV1";
			this.btnV1.Size = new System.Drawing.Size(33, 37);
			this.btnV1.Text = "i:";
			this.btnV1.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton14
			// 
			this.toolStripButton14.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton14.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton14.Image")));
			this.toolStripButton14.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton14.Name = "toolStripButton14";
			this.toolStripButton14.Size = new System.Drawing.Size(25, 37);
			this.toolStripButton14.Text = "i";
			this.toolStripButton14.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// btnV2
			// 
			this.btnV2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.btnV2.Image = ((System.Drawing.Image)(resources.GetObject("btnV2.Image")));
			this.btnV2.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.btnV2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
			this.btnV2.ImageTransparentColor = System.Drawing.Color.White;
			this.btnV2.Name = "btnV2";
			this.btnV2.Size = new System.Drawing.Size(28, 37);
			this.btnV2.Text = "!";
			this.btnV2.ToolTipText = "i 上下顛倒";
			this.btnV2.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// btnV3
			// 
			this.btnV3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.btnV3.Image = ((System.Drawing.Image)(resources.GetObject("btnV3.Image")));
			this.btnV3.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnV3.Name = "btnV3";
			this.btnV3.Size = new System.Drawing.Size(33, 37);
			this.btnV3.Text = "e";
			this.btnV3.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// btnV4
			// 
			this.btnV4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.btnV4.Image = ((System.Drawing.Image)(resources.GetObject("btnV4.Image")));
			this.btnV4.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnV4.Name = "btnV4";
			this.btnV4.Size = new System.Drawing.Size(32, 37);
			this.btnV4.Text = "ɛ";
			this.btnV4.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// btnV5
			// 
			this.btnV5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.btnV5.Image = ((System.Drawing.Image)(resources.GetObject("btnV5.Image")));
			this.btnV5.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnV5.Name = "btnV5";
			this.btnV5.Size = new System.Drawing.Size(41, 37);
			this.btnV5.Text = "æ";
			this.btnV5.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// btnV6
			// 
			this.btnV6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.btnV6.Image = ((System.Drawing.Image)(resources.GetObject("btnV6.Image")));
			this.btnV6.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnV6.Name = "btnV6";
			this.btnV6.Size = new System.Drawing.Size(33, 37);
			this.btnV6.Text = "a";
			this.btnV6.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// btnV7
			// 
			this.btnV7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.btnV7.Image = ((System.Drawing.Image)(resources.GetObject("btnV7.Image")));
			this.btnV7.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnV7.Name = "btnV7";
			this.btnV7.Size = new System.Drawing.Size(41, 37);
			this.btnV7.Text = "ɑ:";
			this.btnV7.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// btnV8
			// 
			this.btnV8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.btnV8.Image = ((System.Drawing.Image)(resources.GetObject("btnV8.Image")));
			this.btnV8.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnV8.Name = "btnV8";
			this.btnV8.Size = new System.Drawing.Size(33, 37);
			this.btnV8.Text = "ɑ";
			this.btnV8.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// btnV9
			// 
			this.btnV9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.btnV9.Image = ((System.Drawing.Image)(resources.GetObject("btnV9.Image")));
			this.btnV9.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnV9.Name = "btnV9";
			this.btnV9.Size = new System.Drawing.Size(33, 37);
			this.btnV9.Text = "ɒ";
			this.btnV9.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// btnV10
			// 
			this.btnV10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.btnV10.Image = ((System.Drawing.Image)(resources.GetObject("btnV10.Image")));
			this.btnV10.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnV10.Name = "btnV10";
			this.btnV10.Size = new System.Drawing.Size(29, 37);
			this.btnV10.Text = "ɪ";
			this.btnV10.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// btnV11
			// 
			this.btnV11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.btnV11.Image = ((System.Drawing.Image)(resources.GetObject("btnV11.Image")));
			this.btnV11.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.btnV11.Name = "btnV11";
			this.btnV11.Size = new System.Drawing.Size(33, 37);
			this.btnV11.Text = "ɐ";
			this.btnV11.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton9
			// 
			this.toolStripButton9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton9.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton9.Image")));
			this.toolStripButton9.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton9.Name = "toolStripButton9";
			this.toolStripButton9.Size = new System.Drawing.Size(40, 37);
			this.toolStripButton9.Text = "ɔ:";
			this.toolStripButton9.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton7
			// 
			this.toolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton7.Image")));
			this.toolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton7.Name = "toolStripButton7";
			this.toolStripButton7.Size = new System.Drawing.Size(33, 37);
			this.toolStripButton7.Text = "o";
			this.toolStripButton7.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton8
			// 
			this.toolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton8.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton8.Image")));
			this.toolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton8.Name = "toolStripButton8";
			this.toolStripButton8.Size = new System.Drawing.Size(32, 37);
			this.toolStripButton8.Text = "ɔ";
			this.toolStripButton8.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton59
			// 
			this.toolStripButton59.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton59.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton59.Image")));
			this.toolStripButton59.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton59.Name = "toolStripButton59";
			this.toolStripButton59.Size = new System.Drawing.Size(34, 37);
			this.toolStripButton59.Text = "ʉ";
			this.toolStripButton59.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStrip4
			// 
			this.toolStrip4.Font = new System.Drawing.Font("Arial Unicode MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.toolStrip4.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
			this.toolStrip4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel3,
            this.toolStripSeparator3,
            this.toolStripButton60,
            this.toolStripButton61,
            this.toolStripButton62,
            this.toolStripButton63,
            this.toolStripButton64,
            this.toolStripButton65,
            this.toolStripButton66,
            this.toolStripButton67,
            this.toolStripButton68,
            this.toolStripButton69,
            this.toolStripButton70,
            this.toolStripButton11,
            this.toolStripButton71,
            this.toolStripButton72,
            this.toolStripButton12});
			this.toolStrip4.Location = new System.Drawing.Point(0, 40);
			this.toolStrip4.Name = "toolStrip4";
			this.toolStrip4.Size = new System.Drawing.Size(656, 40);
			this.toolStrip4.TabIndex = 4;
			this.toolStrip4.Text = "toolStrip4";
			// 
			// toolStripLabel3
			// 
			this.toolStripLabel3.Font = new System.Drawing.Font("PMingLiU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
			this.toolStripLabel3.Name = "toolStripLabel3";
			this.toolStripLabel3.Size = new System.Drawing.Size(42, 37);
			this.toolStripLabel3.Text = "母音";
			// 
			// toolStripSeparator3
			// 
			this.toolStripSeparator3.Name = "toolStripSeparator3";
			this.toolStripSeparator3.Size = new System.Drawing.Size(6, 40);
			// 
			// toolStripButton60
			// 
			this.toolStripButton60.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton60.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton60.Image")));
			this.toolStripButton60.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton60.Name = "toolStripButton60";
			this.toolStripButton60.Size = new System.Drawing.Size(41, 37);
			this.toolStripButton60.Text = "u:";
			this.toolStripButton60.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton61
			// 
			this.toolStripButton61.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton61.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton61.Image")));
			this.toolStripButton61.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton61.Name = "toolStripButton61";
			this.toolStripButton61.Size = new System.Drawing.Size(33, 37);
			this.toolStripButton61.Text = "u";
			this.toolStripButton61.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton62
			// 
			this.toolStripButton62.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton62.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton62.Image")));
			this.toolStripButton62.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton62.Name = "toolStripButton62";
			this.toolStripButton62.Size = new System.Drawing.Size(33, 37);
			this.toolStripButton62.Text = "ʊ";
			this.toolStripButton62.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton63
			// 
			this.toolStripButton63.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton63.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton63.Image")));
			this.toolStripButton63.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton63.Name = "toolStripButton63";
			this.toolStripButton63.Size = new System.Drawing.Size(42, 37);
			this.toolStripButton63.Text = "ʊr";
			this.toolStripButton63.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton64
			// 
			this.toolStripButton64.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton64.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton64.Image")));
			this.toolStripButton64.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton64.Name = "toolStripButton64";
			this.toolStripButton64.Size = new System.Drawing.Size(32, 37);
			this.toolStripButton64.Text = "ʌ";
			this.toolStripButton64.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton65
			// 
			this.toolStripButton65.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton65.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton65.Image")));
			this.toolStripButton65.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton65.Name = "toolStripButton65";
			this.toolStripButton65.Size = new System.Drawing.Size(33, 37);
			this.toolStripButton65.Text = "ə";
			this.toolStripButton65.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton66
			// 
			this.toolStripButton66.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton66.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton66.Image")));
			this.toolStripButton66.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton66.Name = "toolStripButton66";
			this.toolStripButton66.Size = new System.Drawing.Size(32, 37);
			this.toolStripButton66.Text = "ɜ";
			this.toolStripButton66.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton67
			// 
			this.toolStripButton67.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton67.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton67.Image")));
			this.toolStripButton67.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton67.Name = "toolStripButton67";
			this.toolStripButton67.Size = new System.Drawing.Size(36, 37);
			this.toolStripButton67.Text = "ɝ";
			this.toolStripButton67.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton68
			// 
			this.toolStripButton68.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton68.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton68.Image")));
			this.toolStripButton68.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton68.Name = "toolStripButton68";
			this.toolStripButton68.Size = new System.Drawing.Size(39, 37);
			this.toolStripButton68.Text = "ɚ";
			this.toolStripButton68.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton69
			// 
			this.toolStripButton69.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton69.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton69.Image")));
			this.toolStripButton69.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton69.Name = "toolStripButton69";
			this.toolStripButton69.Size = new System.Drawing.Size(36, 37);
			this.toolStripButton69.Text = "Y";
			this.toolStripButton69.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton70
			// 
			this.toolStripButton70.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton70.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton70.Image")));
			this.toolStripButton70.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton70.Name = "toolStripButton70";
			this.toolStripButton70.Size = new System.Drawing.Size(32, 37);
			this.toolStripButton70.Text = "y";
			this.toolStripButton70.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton11
			// 
			this.toolStripButton11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton11.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton11.Image")));
			this.toolStripButton11.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton11.Name = "toolStripButton11";
			this.toolStripButton11.Size = new System.Drawing.Size(43, 37);
			this.toolStripButton11.Text = "aɪ";
			this.toolStripButton11.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton71
			// 
			this.toolStripButton71.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton71.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton71.Image")));
			this.toolStripButton71.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton71.Name = "toolStripButton71";
			this.toolStripButton71.Size = new System.Drawing.Size(47, 37);
			this.toolStripButton71.Text = "aʊ";
			this.toolStripButton71.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton72
			// 
			this.toolStripButton72.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton72.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton72.Image")));
			this.toolStripButton72.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton72.Name = "toolStripButton72";
			this.toolStripButton72.Size = new System.Drawing.Size(37, 37);
			this.toolStripButton72.Text = "ɶ";
			this.toolStripButton72.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton12
			// 
			this.toolStripButton12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton12.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton12.Image")));
			this.toolStripButton12.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton12.Name = "toolStripButton12";
			this.toolStripButton12.Size = new System.Drawing.Size(42, 37);
			this.toolStripButton12.Text = "ɔɪ";
			this.toolStripButton12.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStrip2
			// 
			this.toolStrip2.Font = new System.Drawing.Font("Arial Unicode MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.toolStrip2.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
			this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel2,
            this.toolStripSeparator2,
            this.toolStripButton38,
            this.toolStripButton37,
            this.toolStripButton36,
            this.toolStripButton35,
            this.toolStripButton34,
            this.toolStripButton33,
            this.toolStripButton32,
            this.toolStripButton31,
            this.toolStripButton30,
            this.toolStripButton13,
            this.toolStripButton29,
            this.toolStripButton28,
            this.toolStripButton27,
            this.toolStripButton26,
            this.toolStripButton25,
            this.toolStripButton24,
            this.toolStripButton23});
			this.toolStrip2.Location = new System.Drawing.Point(0, 80);
			this.toolStrip2.Name = "toolStrip2";
			this.toolStrip2.Size = new System.Drawing.Size(656, 40);
			this.toolStrip2.TabIndex = 5;
			// 
			// toolStripLabel2
			// 
			this.toolStripLabel2.Font = new System.Drawing.Font("PMingLiU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
			this.toolStripLabel2.Name = "toolStripLabel2";
			this.toolStripLabel2.Size = new System.Drawing.Size(42, 37);
			this.toolStripLabel2.Text = "子音";
			// 
			// toolStripSeparator2
			// 
			this.toolStripSeparator2.Name = "toolStripSeparator2";
			this.toolStripSeparator2.Size = new System.Drawing.Size(6, 40);
			// 
			// toolStripButton38
			// 
			this.toolStripButton38.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton38.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton38.Image")));
			this.toolStripButton38.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton38.Name = "toolStripButton38";
			this.toolStripButton38.Size = new System.Drawing.Size(33, 37);
			this.toolStripButton38.Text = "p";
			this.toolStripButton38.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton37
			// 
			this.toolStripButton37.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton37.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton37.Image")));
			this.toolStripButton37.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton37.Name = "toolStripButton37";
			this.toolStripButton37.Size = new System.Drawing.Size(33, 37);
			this.toolStripButton37.Text = "b";
			this.toolStripButton37.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton36
			// 
			this.toolStripButton36.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton36.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton36.Image")));
			this.toolStripButton36.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton36.Name = "toolStripButton36";
			this.toolStripButton36.Size = new System.Drawing.Size(27, 37);
			this.toolStripButton36.Text = "t";
			this.toolStripButton36.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton35
			// 
			this.toolStripButton35.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton35.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton35.Image")));
			this.toolStripButton35.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton35.Name = "toolStripButton35";
			this.toolStripButton35.Size = new System.Drawing.Size(33, 37);
			this.toolStripButton35.Text = "d";
			this.toolStripButton35.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton34
			// 
			this.toolStripButton34.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton34.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton34.Image")));
			this.toolStripButton34.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton34.Name = "toolStripButton34";
			this.toolStripButton34.Size = new System.Drawing.Size(32, 37);
			this.toolStripButton34.Text = "k";
			this.toolStripButton34.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton33
			// 
			this.toolStripButton33.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton33.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton33.Image")));
			this.toolStripButton33.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton33.Name = "toolStripButton33";
			this.toolStripButton33.Size = new System.Drawing.Size(33, 37);
			this.toolStripButton33.Text = "g";
			this.toolStripButton33.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton32
			// 
			this.toolStripButton32.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton32.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton32.Image")));
			this.toolStripButton32.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton32.Name = "toolStripButton32";
			this.toolStripButton32.Size = new System.Drawing.Size(33, 37);
			this.toolStripButton32.Text = "q";
			this.toolStripButton32.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton31
			// 
			this.toolStripButton31.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton31.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton31.Image")));
			this.toolStripButton31.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton31.Name = "toolStripButton31";
			this.toolStripButton31.Size = new System.Drawing.Size(39, 37);
			this.toolStripButton31.Text = "G";
			this.toolStripButton31.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton30
			// 
			this.toolStripButton30.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton30.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton30.Image")));
			this.toolStripButton30.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton30.Name = "toolStripButton30";
			this.toolStripButton30.Size = new System.Drawing.Size(39, 37);
			this.toolStripButton30.Text = "m";
			this.toolStripButton30.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton13
			// 
			this.toolStripButton13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton13.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton13.Image")));
			this.toolStripButton13.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton13.Name = "toolStripButton13";
			this.toolStripButton13.Size = new System.Drawing.Size(33, 37);
			this.toolStripButton13.Text = "n";
			this.toolStripButton13.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton29
			// 
			this.toolStripButton29.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolStripButton29.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton29.Image")));
			this.toolStripButton29.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.toolStripButton29.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
			this.toolStripButton29.ImageTransparentColor = System.Drawing.Color.White;
			this.toolStripButton29.Name = "toolStripButton29";
			this.toolStripButton29.Size = new System.Drawing.Size(28, 37);
			this.toolStripButton29.Text = "ɳ";
			this.toolStripButton29.ToolTipText = "ɳ：n 底下一點";
			this.toolStripButton29.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton28
			// 
			this.toolStripButton28.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton28.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton28.Image")));
			this.toolStripButton28.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton28.Name = "toolStripButton28";
			this.toolStripButton28.Size = new System.Drawing.Size(33, 37);
			this.toolStripButton28.Text = "ŋ";
			this.toolStripButton28.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton27
			// 
			this.toolStripButton27.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton27.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton27.Image")));
			this.toolStripButton27.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton27.Name = "toolStripButton27";
			this.toolStripButton27.Size = new System.Drawing.Size(37, 37);
			this.toolStripButton27.Text = "w";
			this.toolStripButton27.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton26
			// 
			this.toolStripButton26.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton26.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton26.Image")));
			this.toolStripButton26.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton26.Name = "toolStripButton26";
			this.toolStripButton26.Size = new System.Drawing.Size(25, 37);
			this.toolStripButton26.Text = "l";
			this.toolStripButton26.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton25
			// 
			this.toolStripButton25.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton25.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton25.Image")));
			this.toolStripButton25.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton25.Name = "toolStripButton25";
			this.toolStripButton25.Size = new System.Drawing.Size(27, 37);
			this.toolStripButton25.Text = "f";
			this.toolStripButton25.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton24
			// 
			this.toolStripButton24.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton24.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton24.Image")));
			this.toolStripButton24.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton24.Name = "toolStripButton24";
			this.toolStripButton24.Size = new System.Drawing.Size(32, 37);
			this.toolStripButton24.Text = "v";
			this.toolStripButton24.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton23
			// 
			this.toolStripButton23.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton23.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton23.Image")));
			this.toolStripButton23.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton23.Name = "toolStripButton23";
			this.toolStripButton23.Size = new System.Drawing.Size(33, 37);
			this.toolStripButton23.Text = "ɵ";
			this.toolStripButton23.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStrip3
			// 
			this.toolStrip3.Font = new System.Drawing.Font("Arial Unicode MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.toolStrip3.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
			this.toolStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel4,
            this.toolStripSeparator4,
            this.toolStripButton22,
            this.toolStripButton90,
            this.toolStripButton91,
            this.toolStripButton92,
            this.toolStripButton93,
            this.toolStripButton94,
            this.toolStripButton95,
            this.toolStripButton96,
            this.toolStripButton97,
            this.toolStripButton98,
            this.toolStripButton4,
            this.toolStripButton3,
            this.toolStripButton2,
            this.toolStripButton1,
            this.toolStripButton5,
            this.toolStripButton99});
			this.toolStrip3.Location = new System.Drawing.Point(0, 120);
			this.toolStrip3.Name = "toolStrip3";
			this.toolStrip3.Size = new System.Drawing.Size(656, 40);
			this.toolStrip3.TabIndex = 6;
			// 
			// toolStripLabel4
			// 
			this.toolStripLabel4.Font = new System.Drawing.Font("PMingLiU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
			this.toolStripLabel4.Name = "toolStripLabel4";
			this.toolStripLabel4.Size = new System.Drawing.Size(42, 37);
			this.toolStripLabel4.Text = "子音";
			// 
			// toolStripSeparator4
			// 
			this.toolStripSeparator4.Name = "toolStripSeparator4";
			this.toolStripSeparator4.Size = new System.Drawing.Size(6, 40);
			// 
			// toolStripButton22
			// 
			this.toolStripButton22.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton22.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton22.Image")));
			this.toolStripButton22.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton22.Name = "toolStripButton22";
			this.toolStripButton22.Size = new System.Drawing.Size(33, 37);
			this.toolStripButton22.Text = "ð";
			this.toolStripButton22.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton90
			// 
			this.toolStripButton90.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton90.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton90.Image")));
			this.toolStripButton90.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton90.Name = "toolStripButton90";
			this.toolStripButton90.Size = new System.Drawing.Size(32, 37);
			this.toolStripButton90.Text = "s";
			this.toolStripButton90.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton91
			// 
			this.toolStripButton91.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton91.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton91.Image")));
			this.toolStripButton91.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton91.Name = "toolStripButton91";
			this.toolStripButton91.Size = new System.Drawing.Size(32, 37);
			this.toolStripButton91.Text = "z";
			this.toolStripButton91.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton92
			// 
			this.toolStripButton92.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton92.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton92.Image")));
			this.toolStripButton92.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton92.Name = "toolStripButton92";
			this.toolStripButton92.Size = new System.Drawing.Size(28, 37);
			this.toolStripButton92.Text = "ɹ";
			this.toolStripButton92.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton93
			// 
			this.toolStripButton93.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton93.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton93.Image")));
			this.toolStripButton93.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton93.Name = "toolStripButton93";
			this.toolStripButton93.Size = new System.Drawing.Size(33, 37);
			this.toolStripButton93.Text = "ɥ";
			this.toolStripButton93.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton94
			// 
			this.toolStripButton94.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton94.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton94.Image")));
			this.toolStripButton94.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton94.Name = "toolStripButton94";
			this.toolStripButton94.Size = new System.Drawing.Size(33, 37);
			this.toolStripButton94.Text = "h";
			this.toolStripButton94.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton95
			// 
			this.toolStripButton95.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton95.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton95.Image")));
			this.toolStripButton95.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton95.Name = "toolStripButton95";
			this.toolStripButton95.Size = new System.Drawing.Size(25, 37);
			this.toolStripButton95.Text = "ʃ";
			this.toolStripButton95.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton96
			// 
			this.toolStripButton96.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton96.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton96.Image")));
			this.toolStripButton96.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton96.Name = "toolStripButton96";
			this.toolStripButton96.Size = new System.Drawing.Size(33, 37);
			this.toolStripButton96.Text = "ʒ";
			this.toolStripButton96.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton97
			// 
			this.toolStripButton97.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton97.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton97.Image")));
			this.toolStripButton97.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton97.Name = "toolStripButton97";
			this.toolStripButton97.Size = new System.Drawing.Size(28, 37);
			this.toolStripButton97.Text = "r";
			this.toolStripButton97.ToolTipText = "s";
			this.toolStripButton97.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton98
			// 
			this.toolStripButton98.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton98.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton98.Image")));
			this.toolStripButton98.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton98.Name = "toolStripButton98";
			this.toolStripButton98.Size = new System.Drawing.Size(37, 37);
			this.toolStripButton98.Text = "R";
			this.toolStripButton98.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton4
			// 
			this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
			this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton4.Name = "toolStripButton4";
			this.toolStripButton4.Size = new System.Drawing.Size(25, 37);
			this.toolStripButton4.Text = "j";
			this.toolStripButton4.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton3
			// 
			this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
			this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton3.Name = "toolStripButton3";
			this.toolStripButton3.Size = new System.Drawing.Size(33, 37);
			this.toolStripButton3.Text = "tʃ";
			this.toolStripButton3.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton2
			// 
			this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
			this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton2.Name = "toolStripButton2";
			this.toolStripButton2.Size = new System.Drawing.Size(47, 37);
			this.toolStripButton2.Text = "dʒ";
			this.toolStripButton2.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton1
			// 
			this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
			this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton1.Name = "toolStripButton1";
			this.toolStripButton1.Size = new System.Drawing.Size(40, 37);
			this.toolStripButton1.Text = "ts";
			this.toolStripButton1.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton5
			// 
			this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
			this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton5.Name = "toolStripButton5";
			this.toolStripButton5.Size = new System.Drawing.Size(46, 37);
			this.toolStripButton5.Text = "dz";
			this.toolStripButton5.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton99
			// 
			this.toolStripButton99.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton99.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton99.Image")));
			this.toolStripButton99.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton99.Name = "toolStripButton99";
			this.toolStripButton99.Size = new System.Drawing.Size(51, 37);
			this.toolStripButton99.Text = "hw";
			this.toolStripButton99.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStrip5
			// 
			this.toolStrip5.Font = new System.Drawing.Font("Arial Unicode MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.toolStrip5.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
			this.toolStrip5.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel5,
            this.toolStripSeparator5,
            this.toolStripButton6,
            this.toolStripButton10});
			this.toolStrip5.Location = new System.Drawing.Point(0, 160);
			this.toolStrip5.Name = "toolStrip5";
			this.toolStrip5.Size = new System.Drawing.Size(656, 40);
			this.toolStrip5.TabIndex = 7;
			// 
			// toolStripLabel5
			// 
			this.toolStripLabel5.Font = new System.Drawing.Font("PMingLiU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
			this.toolStripLabel5.Name = "toolStripLabel5";
			this.toolStripLabel5.Size = new System.Drawing.Size(42, 37);
			this.toolStripLabel5.Text = "重音";
			// 
			// toolStripSeparator5
			// 
			this.toolStripSeparator5.Name = "toolStripSeparator5";
			this.toolStripSeparator5.Size = new System.Drawing.Size(6, 40);
			// 
			// toolStripButton6
			// 
			this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
			this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton6.Name = "toolStripButton6";
			this.toolStripButton6.Size = new System.Drawing.Size(25, 37);
			this.toolStripButton6.Text = "\'";
			this.toolStripButton6.ToolTipText = "重音";
			this.toolStripButton6.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// toolStripButton10
			// 
			this.toolStripButton10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripButton10.Font = new System.Drawing.Font("Arial Unicode MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.toolStripButton10.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton10.Image")));
			this.toolStripButton10.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton10.Name = "toolStripButton10";
			this.toolStripButton10.Size = new System.Drawing.Size(27, 37);
			this.toolStripButton10.Text = ",";
			this.toolStripButton10.ToolTipText = "次重音";
			this.toolStripButton10.Click += new System.EventHandler(this.phoneticBtn_Click);
			// 
			// btnOk
			// 
			this.btnOk.Location = new System.Drawing.Point(470, 266);
			this.btnOk.Name = "btnOk";
			this.btnOk.Size = new System.Drawing.Size(77, 33);
			this.btnOk.TabIndex = 8;
			this.btnOk.Text = "確定";
			this.btnOk.UseVisualStyleBackColor = true;
			this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(12, 226);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(112, 15);
			this.label1.TabIndex = 9;
			this.label1.Text = "欲插入的音標：";
			// 
			// txtPhonetic
			// 
			this.txtPhonetic.Font = new System.Drawing.Font("Arial Unicode MS", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
			this.txtPhonetic.Location = new System.Drawing.Point(120, 219);
			this.txtPhonetic.Name = "txtPhonetic";
			this.txtPhonetic.Size = new System.Drawing.Size(340, 28);
			this.txtPhonetic.TabIndex = 10;
			// 
			// btnCancel
			// 
			this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancel.Location = new System.Drawing.Point(556, 266);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(77, 33);
			this.btnCancel.TabIndex = 11;
			this.btnCancel.Text = "取消";
			this.btnCancel.UseVisualStyleBackColor = true;
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("MingLiU", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
			this.label2.ForeColor = System.Drawing.Color.Maroon;
			this.label2.Location = new System.Drawing.Point(12, 266);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(438, 33);
			this.label2.TabIndex = 12;
			this.label2.Text = "注意：由於文字字型的限制，實際列印時有些音標會以不同符號呈現，例如：驚嘆號 (!) 代表上下顛倒的 i ，逗號 (,) 代表次重音。";
			// 
			// chkAddBracket
			// 
			this.chkAddBracket.AutoSize = true;
			this.chkAddBracket.Checked = true;
			this.chkAddBracket.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkAddBracket.Location = new System.Drawing.Point(480, 225);
			this.chkAddBracket.Name = "chkAddBracket";
			this.chkAddBracket.Size = new System.Drawing.Size(149, 19);
			this.chkAddBracket.TabIndex = 13;
			this.chkAddBracket.Text = "自動加音標括號 [ ]";
			this.chkAddBracket.UseVisualStyleBackColor = true;
			// 
			// PhoneticForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.CancelButton = this.btnCancel;
			this.ClientSize = new System.Drawing.Size(656, 314);
			this.Controls.Add(this.chkAddBracket);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.txtPhonetic);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btnOk);
			this.Controls.Add(this.toolStrip5);
			this.Controls.Add(this.toolStrip3);
			this.Controls.Add(this.toolStrip2);
			this.Controls.Add(this.toolStrip4);
			this.Controls.Add(this.toolStrip1);
			this.Font = new System.Drawing.Font("PMingLiU", 11F);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Margin = new System.Windows.Forms.Padding(4);
			this.Name = "PhoneticForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "插入音標";
			this.Load += new System.EventHandler(this.PhoneticForm_Load);
			this.toolStrip1.ResumeLayout(false);
			this.toolStrip1.PerformLayout();
			this.toolStrip4.ResumeLayout(false);
			this.toolStrip4.PerformLayout();
			this.toolStrip2.ResumeLayout(false);
			this.toolStrip2.PerformLayout();
			this.toolStrip3.ResumeLayout(false);
			this.toolStrip3.PerformLayout();
			this.toolStrip5.ResumeLayout(false);
			this.toolStrip5.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.ToolStrip toolStrip1;
		private System.Windows.Forms.ToolStripButton btnV1;
		private System.Windows.Forms.ToolStripButton btnV2;
		private System.Windows.Forms.ToolStripButton btnV3;
		private System.Windows.Forms.ToolStripButton btnV4;
		private System.Windows.Forms.ToolStripButton btnV5;
		private System.Windows.Forms.ToolStripButton btnV6;
		private System.Windows.Forms.ToolStripButton btnV7;
		private System.Windows.Forms.ToolStripButton btnV8;
		private System.Windows.Forms.ToolStripButton btnV9;
		private System.Windows.Forms.ToolStripButton btnV10;
		private System.Windows.Forms.ToolStripButton btnV11;
		private System.Windows.Forms.ToolStripButton toolStripButton9;
		private System.Windows.Forms.ToolStripButton toolStripButton8;
		private System.Windows.Forms.ToolStripButton toolStripButton7;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
		private System.Windows.Forms.ToolStrip toolStrip4;
		private System.Windows.Forms.ToolStripLabel toolStripLabel3;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
		private System.Windows.Forms.ToolStripButton toolStripButton60;
		private System.Windows.Forms.ToolStripButton toolStripButton61;
		private System.Windows.Forms.ToolStripButton toolStripButton62;
		private System.Windows.Forms.ToolStripButton toolStripButton63;
		private System.Windows.Forms.ToolStripButton toolStripButton64;
		private System.Windows.Forms.ToolStripButton toolStripButton65;
		private System.Windows.Forms.ToolStripButton toolStripButton66;
		private System.Windows.Forms.ToolStripButton toolStripButton67;
		private System.Windows.Forms.ToolStripButton toolStripButton68;
		private System.Windows.Forms.ToolStripButton toolStripButton69;
		private System.Windows.Forms.ToolStripButton toolStripButton70;
		private System.Windows.Forms.ToolStripButton toolStripButton71;
		private System.Windows.Forms.ToolStripButton toolStripButton72;
		private System.Windows.Forms.ToolStripLabel toolStripLabel1;
		private System.Windows.Forms.ToolStrip toolStrip2;
		private System.Windows.Forms.ToolStripLabel toolStripLabel2;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
		private System.Windows.Forms.ToolStripButton toolStripButton38;
		private System.Windows.Forms.ToolStripButton toolStripButton37;
		private System.Windows.Forms.ToolStripButton toolStripButton36;
		private System.Windows.Forms.ToolStripButton toolStripButton35;
		private System.Windows.Forms.ToolStripButton toolStripButton34;
		private System.Windows.Forms.ToolStripButton toolStripButton33;
		private System.Windows.Forms.ToolStripButton toolStripButton32;
		private System.Windows.Forms.ToolStripButton toolStripButton31;
		private System.Windows.Forms.ToolStripButton toolStripButton30;
		private System.Windows.Forms.ToolStripButton toolStripButton29;
		private System.Windows.Forms.ToolStripButton toolStripButton28;
		private System.Windows.Forms.ToolStripButton toolStripButton27;
		private System.Windows.Forms.ToolStripButton toolStripButton26;
		private System.Windows.Forms.ToolStripButton toolStripButton25;
		private System.Windows.Forms.ToolStripButton toolStripButton24;
		private System.Windows.Forms.ToolStripButton toolStripButton23;
		private System.Windows.Forms.ToolStrip toolStrip3;
		private System.Windows.Forms.ToolStripLabel toolStripLabel4;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
		private System.Windows.Forms.ToolStripButton toolStripButton90;
		private System.Windows.Forms.ToolStripButton toolStripButton91;
		private System.Windows.Forms.ToolStripButton toolStripButton92;
		private System.Windows.Forms.ToolStripButton toolStripButton93;
		private System.Windows.Forms.ToolStripButton toolStripButton94;
		private System.Windows.Forms.ToolStripButton toolStripButton95;
		private System.Windows.Forms.ToolStripButton toolStripButton96;
		private System.Windows.Forms.ToolStripButton toolStripButton97;
		private System.Windows.Forms.ToolStripButton toolStripButton98;
		private System.Windows.Forms.ToolStripButton toolStripButton99;
		private System.Windows.Forms.ToolStripButton toolStripButton4;
		private System.Windows.Forms.ToolStripButton toolStripButton3;
		private System.Windows.Forms.ToolStripButton toolStripButton2;
		private System.Windows.Forms.ToolStripButton toolStripButton1;
		private System.Windows.Forms.ToolStripButton toolStripButton5;
		private System.Windows.Forms.ToolStrip toolStrip5;
		private System.Windows.Forms.ToolStripLabel toolStripLabel5;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
		private System.Windows.Forms.ToolStripButton toolStripButton6;
		private System.Windows.Forms.ToolStripButton toolStripButton10;
		private System.Windows.Forms.Button btnOk;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtPhonetic;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.ToolStripButton toolStripButton59;
		private System.Windows.Forms.ToolStripButton toolStripButton11;
		private System.Windows.Forms.ToolStripButton toolStripButton12;
		private System.Windows.Forms.ToolStripButton toolStripButton13;
		private System.Windows.Forms.ToolStripButton toolStripButton22;
		private System.Windows.Forms.ToolStripButton toolStripButton14;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.CheckBox chkAddBracket;
	}
}