using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.Globalization;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using Huanlin.Braille;
using Huanlin.Braille.Converters;
using Huanlin.WinForms;
using Huanlin.Text;
using DevAge.Windows.Forms;

namespace EasyBrailleEdit
{
	public enum ViewMode { All, BrailleOnly, TextAndZhuyin };

	public partial class DualEditForm : Form
	{
		private const int FixedColumns = 1;
		private const int FixedRows = 1;
		private const float DefaultHeaderFontSize = 9.0f;
		private const float DefaultBrailleFontSize = 19.5f;
		private const float DefaultTextFontSize = 11.25f;
		private const float DefaultPhoneticFontSize = 7.0f;

		private bool m_IsInitialized = false;
		private BrailleDocument m_BrDoc;
		private string m_FileName;
		private bool m_IsDirty;   // �ɮפ��e�O�_�Q�ק�L

		private ViewMode m_ViewMode = ViewMode.All;

		private DualEditFindForm m_FindForm;

		#region �� Grid �ϥΪ�����

		private SourceGrid.Cells.Views.Header m_HeaderView;
		private SourceGrid.Cells.Views.Header m_HeaderView2;    // for �C�@�����_�l�C�A�ΥH��O�s�����}�l�C
		private SourceGrid.Cells.Views.Cell m_BrView;   // Grid cell view for �I�r
		private SourceGrid.Cells.Views.Cell m_MingView; // Grid cell view for �����r
		private SourceGrid.Cells.Views.Cell m_PhonView; // Grid cell view for �`���Ÿ�
		private SourceGrid.Cells.Views.Cell m_PhonView2; // Grid cell view for �}���r���`���Ÿ�
		private SourceGrid.Cells.Views.Cell m_PhonView3; // Grid cell view for �e���P�_���~���}���r�`���Ÿ�
		private Font m_MingFont;	// Grid cell �r�� for �����r
		private Font m_PhonFont;	// Grid cell �r�� for �`���Ÿ�
		private PopupMenuController m_MenuController;
		private CellClickEvent m_ClickController;

		#endregion

		private bool m_DebugMode = true;   // �����Ҧ�

		public DualEditForm(BrailleDocument brDoc)
			: base()
		{
			m_BrDoc = brDoc;

			InitializeComponent();
		}

		public DualEditForm(string btxFileName)
			: base()
		{
			InitializeComponent();

			InternalLoadFile(btxFileName);
		}

		#region �ݩ�

		public BrailleDocument BrailleDoc
		{
			get { return m_BrDoc; }
		}

		public string FileName
		{
			get { return m_FileName; }
			set
			{
				// �p�G�O�Ȧs����X�ɦW�A�h�����|���s�ɡC
				if (value.ToLower().IndexOf(AppConst.CvtOutputTempFileName.ToLower()) >= 0)
				{
					m_IsDirty = true;
				}
				m_FileName = value;
				UpdateWindowCaption();
			}
		}

		public bool DebugMode
		{
			get { return m_DebugMode; }
			set { m_DebugMode = value; }
		}

		public StatusStrip StatusBar
		{
			get { return this.statusStrip1; }
		}

		public string StatusText
		{
			get { return statMessage.Text; }
			set
			{
				statMessage.Text = value;
				statusStrip1.Refresh();
			}
		}

		public string PageNumberText
		{
			get { return statPageInfo.Text; }
			set { statPageInfo.Text = value; }
		}

		/// <summary>
		/// ���A�C���i�ת��ƭȡC
		/// </summary>
		public int StatusProgress
		{
			get { return statProgressBar.Value; }
			set
			{
				statProgressBar.Value = value;
			}
		}

		public ViewMode ViewMode
		{
			get { return m_ViewMode; }
			set
			{
				if (m_ViewMode != value)
				{
					m_ViewMode = value;
					if (m_ViewMode == ViewMode.BrailleOnly)
					{
						ViewBrailleOnly();
					}
					else if (m_ViewMode == ViewMode.TextAndZhuyin)
					{
						ViewTextAndZhuyin();
					}
					else
					{
						ViewAll();
					}
				}
			}
		}

		public bool IsDirty
		{
			get { return m_IsDirty; }
			set
			{
				if (m_IsDirty != value)
				{
					m_IsDirty = value;
					UpdateWindowCaption();
				}
			}
		}

		#endregion

		/// <summary>
		/// �P�_�O�_�|���R�W.
		/// </summary>
		/// <returns></returns>
		private bool IsNoName()
		{
			if (String.IsNullOrEmpty(m_FileName))
				return true;

			string fname = StrHelper.ExtractFileName(m_FileName);
			if (fname.Equals(AppConst.CvtOutputTempFileName, StringComparison.CurrentCultureIgnoreCase))
				return true;

			return false;
		}

		private void UpdateWindowCaption()
		{
			if (IsNoName())
			{
				Text = "�����s�� - ���R�W";
			}
			else
			{
				Text = "�����s�� - " + StrHelper.ExtractFileName(m_FileName);
			}

			if (m_IsDirty)
			{
				Text = Text + "*";
			}
		}

		/// <summary>
		/// �Y����ܤ�ҡC
		/// </summary>
		/// <param name="ratio"></param>
		private void Zoom(int ratio)
		{
			if (!m_IsInitialized)
				return;

			if (ratio > 200 || ratio < 30)
			{
				MsgBoxHelper.ShowInfo("���w���Y���ҤӤp�ΤӤj: " + ratio.ToString() + "%");
				return;
			}

			double r = ratio / 100.0;
			float size = 0.0f;

			StatusText = "���b�վ���ܤ��...";
			CursorHelper.ShowWaitCursor();
			try
			{
				// ���D�r��
				size = (float)(DualEditForm.DefaultHeaderFontSize * r);
				m_HeaderView.Font = new Font(brGrid.Font.FontFamily, size);
				//brGrid[0, 1].View.Font = new Font(brGrid[0, 1].View.Font.FontFamily, size);

				m_HeaderView2.Font = m_HeaderView.Font;

				// �I�r�r��
				size = (float)(DualEditForm.DefaultBrailleFontSize * r);
				m_BrView.Font = new Font(m_BrView.Font.FontFamily, size);
				//brGrid[1, 1].View.Font = new Font(brGrid[1, 1].View.Font.FontFamily, size);

				// �����r�r��
				size = (float)(DualEditForm.DefaultTextFontSize * r);
				m_MingView.Font = new Font(m_MingFont.FontFamily, size);
				//brGrid[2, 1].View.Font = new Font(brGrid[2, 1].View.Font.FontFamily, size);

				// �`���Ÿ��r��
				size = (float)(DualEditForm.DefaultPhoneticFontSize * r);
				m_PhonView.Font = new Font(m_PhonView.Font.FontFamily, size);
				m_PhonView2.Font = m_PhonView.Font;
				m_PhonView3.Font = m_PhonView.Font;
				//brGrid[3, 1].View.Font = new Font(brGrid[3, 1].View.Font.FontFamily, size);

				brGrid.Columns.AutoSizeView();
			}
			finally
			{
				CursorHelper.RestoreCursor();
				StatusText = "";
			}
		}

		private void DualEditForm_Load(object sender, EventArgs e)
		{
			cboZoom.SelectedIndex = 2;  // 100%
			cboZoom.Width = 50;

			txtGotoPageNum.Width = 50;

			brGrid.AutoSizeMode = AutoSizeMode.GrowAndShrink;

			m_ViewMode = ViewMode.All;
			miViewAll.Checked = true;

			// �Y FileName ���O null�A���ܦb�غc���w�g���J�L�ɮסA��������l�ưʧ@�N���n���а��C
			if (String.IsNullOrEmpty(m_FileName))
			{
				InitializeGrid();
				FillGrid(m_BrDoc);
			}

			m_FindForm = new DualEditFindForm();
			m_FindForm.Owner = this;
			m_FindForm.DecidingStartPosition += new DualEditFindForm.DecideStartPositionEvent(FindForm_DecidingStartPosition);
			m_FindForm.TargetFound += new DualEditFindForm.TargetFoundEvent(FindForm_TargetFound);

			this.BringToFront();
			this.Activate();
		}

		void FindForm_DecidingStartPosition(object sender, DualEditFindForm.DecideStartPositionEventArgs args)
		{
			// ��U�M������M�w�n�q���@�Ӧ�m�}�l�M��]�q�ثe�@�Τ����x�s��}�l�^
			int row = brGrid.Selection.ActivePosition.Row;
			int col = brGrid.Selection.ActivePosition.Column;
			if (row < brGrid.FixedRows || col < brGrid.FixedColumns)
			{
				args.LineIndex = 0;
				args.WordIndex = 0;
			}
			else
			{
				args.LineIndex = GetBrailleLineIndex(row);
				args.WordIndex = GetBrailleWordIndex(row, col);
			}
		}

		void FindForm_TargetFound(object sender, DualEditFindForm.TargetFoundEventArgs args)
		{
			int row = GetGridRowIndex(args.LineIndex) + 1;
			int col = GetGridColumnIndex(args.LineIndex, args.WordIndex);
			SourceGrid.Position pos = new SourceGrid.Position(row, col);
			brGrid.Selection.Focus(pos, true);
			brGrid.Selection.SelectCell(pos, true);
		}

		private void InitializeGrid()
		{
			if (m_IsInitialized)
				return;

			// �]�w grid �w�]����e�P�C��
			brGrid.DefaultWidth = 30;
			brGrid.DefaultHeight = 20;

			// �]�w grid �C�ƻP��ơC
			int maxCol = m_BrDoc.CellsPerLine;  // brDoc.LongestLine.Words.Count;
			brGrid.Redim(m_BrDoc.Lines.Count * 3 + FixedRows, maxCol + FixedColumns);

			// �]�w��e�̤p����A�H�K�I�s AutoSizeView �ɡA��e�Q�Y�o�Ӥp�C
			for (int i = 1; i < brGrid.ColumnsCount; i++)
			{
				brGrid.Columns[i].MinimalWidth = 24;
			}
			brGrid.Columns[0].MinimalWidth = 40;	// �� 0 ��n��ܦC���A�ݭn�e��.

			// ���D��
			if (m_HeaderView == null)
			{
				m_HeaderView = new SourceGrid.Cells.Views.Header();
				m_HeaderView.Font = new Font(brGrid.Font, FontStyle.Regular);
			}

			if (m_HeaderView2 == null)
			{
				m_HeaderView2 = new SourceGrid.Cells.Views.RowHeader();
				DevAge.Drawing.VisualElements.RowHeader backHeader = new DevAge.Drawing.VisualElements.RowHeader();
				backHeader.BackColor = Color.Blue;
				m_HeaderView2.Background = backHeader;
				m_HeaderView2.Font = m_HeaderView.Font;
			}

			CreateFixedArea();

			// Font objects

			if (m_PhonFont == null)
			{
				m_PhonFont = new Font("�s�ө���", DualEditForm.DefaultPhoneticFontSize);
			}

			if (m_MingFont == null)
			{
				m_MingFont = new Font("Arial Unicode MS", DualEditForm.DefaultTextFontSize);
				// Note: �쥻���s�ө���A�i�O���F��ܭ^�孵�е��S���Ÿ��A�����ϥ� Arial Unicode MS �r���C
			}

			// view for �I�r
			if (m_BrView == null)
			{
				m_BrView = new SourceGrid.Cells.Views.Cell();
				m_BrView.BackColor = Color.Snow;
				m_BrView.Font = new Font("SimBraille", DualEditForm.DefaultBrailleFontSize);
				m_BrView.TrimmingMode = SourceGrid.TrimmingMode.None;
			}

			// view for �����r
			if (m_MingView == null)
			{
				m_MingView = new SourceGrid.Cells.Views.Cell();
				m_MingView.BackColor = Color.Snow;
				m_MingView.Font = m_MingFont;
				m_MingView.ElementText.Font = m_MingFont;
			}

			// view for �`���Ÿ�
			if (m_PhonView == null)
			{
				m_PhonView = new SourceGrid.Cells.Views.Cell();
				m_PhonView.BackColor = Color.YellowGreen;
				m_PhonView.Font = m_PhonFont;
				m_PhonView.TrimmingMode = SourceGrid.TrimmingMode.None;
			}

			// view for �}���r���`���Ÿ�
			if (m_PhonView2 == null)
			{
				m_PhonView2 = new SourceGrid.Cells.Views.Cell();
				m_PhonView2.BackColor = Color.Yellow;
				m_PhonView2.Font = m_PhonFont;
				m_PhonView2.TrimmingMode = SourceGrid.TrimmingMode.None;
			}
			// view for �e���P�_���~���}���r�`���Ÿ�
			if (m_PhonView3 == null)
			{
				m_PhonView3 = new SourceGrid.Cells.Views.Cell();
				m_PhonView3.BackColor = Color.Red;
				m_PhonView3.Font = m_PhonFont;
				m_PhonView3.TrimmingMode = SourceGrid.TrimmingMode.None;
			}

			// �]�m controllers
			if (m_MenuController == null)
			{
				m_MenuController = new PopupMenuController();
				m_MenuController.PopupMenuClick += new SourceGrid.CellContextEventHandler(GridMenu_Click);
			}

			if (m_ClickController == null)
			{
				m_ClickController = new CellClickEvent(this);
			}

			m_IsInitialized = true;
		}

		/// <summary>
		/// �إߩT�w�x�s�檺���e�A�]�A�G���D�C�B���D��C
		/// </summary>
		private void CreateFixedArea()
		{
			brGrid.FixedColumns = DualEditForm.FixedColumns;
			brGrid.FixedRows = DualEditForm.FixedRows;

			brGrid[0, 0] = new SourceGrid.Cells.Header();
			brGrid[0, 0].View = m_HeaderView;
			brGrid[0, 0].Row.Height = 22;
			//brGrid[0, 0].Column.AutoSizeMode = SourceGrid.AutoSizeMode.EnableAutoSize;

			// column headers
			int cnt = 0;
			for (int col = FixedColumns; col < brGrid.ColumnsCount; col++)
			{
				cnt++;
				SourceGrid.Cells.ColumnHeader hdr = new SourceGrid.Cells.ColumnHeader(cnt.ToString());
				//hdr.EnableResize = false;               
				brGrid[0, col] = hdr;
				brGrid[0, col].View = m_HeaderView;
			}

			// row headers
			cnt = 1;
			for (int row = FixedRows; row < brGrid.RowsCount; row += 3)
			{
				SourceGrid.Cells.RowHeader hdr = new SourceGrid.Cells.RowHeader(cnt.ToString());
				brGrid[row, 0] = hdr;
				brGrid[row, 0].View = m_HeaderView;
				hdr.RowSpan = 3;	// ���i�H�b���w hdr ���󤧫e�]�w RowSpan, �_�h�|�X��!
				cnt++;
			}

			RefreshRowNumbers();
		}

		/// <summary>
		/// �վ�Ҧ��x�s��j�p�C
		/// </summary>
		private void ResizeCells()
		{
			//brGrid.AutoSizeCells(); // �վ�Ҧ��x�s��j�p�A�t�׫D�`�C!!
			brGrid.Columns.AutoSizeView();      // �� AutoSizeCells �֤Q���H�W!
			brGrid.Columns.AutoSizeColumn(0);   // ���s�վ�� 0 ��A�H�T�O��ܦC�����x�s����j�C
		}

		/// <summary>
		///  ��s grid �����Y�@�C�C����k�|�۰ʵ��ݭn�_��A�����w���C���C�C
		/// </summary>
		/// <param name="row">Grid �C���ޡC</param>
		private void ReformatRow(int row)
		{
			row = GetBrailleRowIndex(row);  // �ץ��C���ެ��I�r�C�Ҧb�����ޡC

			int lineIndex = GetBrailleLineIndex(row);
			int lineCnt = BrailleProcessor.GetInstance().FormatLine(m_BrDoc, lineIndex, null);
			if (lineCnt > 1)    // ���_��?
			{
				// ���W�s�C
				RecreateRow(row);
				FillRow(m_BrDoc[lineIndex], row, true);

				// ���J�s�C
				GridInsertRowAt(row + 3);
				FillRow(m_BrDoc[lineIndex + 1], row + 3, true);

				// ���s��C��
				RefreshRowNumbers();
			}
			else
			{
				// ���W�s�C
				RecreateRow(row);
				FillRow(m_BrDoc[lineIndex], row, true);
			}
		}

		/// <summary>
		/// �b���w���C���޷s�W�@�C�]��ڤW�O�T�C�^�C
		/// </summary>
		/// <param name="row"></param>
		private void GridInsertRowAt(int row)
		{
			row = GetBrailleRowIndex(row);  // �T�O�C���ެ��I�r�C�Ҧb�����ޡC
			brGrid.Rows.InsertRange(row, 3);

			// �إߦC���D�x�s��C
			int rowNum = row / 3 + 1;
			SourceGrid.Cells.Header hdr = new SourceGrid.Cells.Header(rowNum.ToString());
			brGrid[row, 0] = hdr;
			brGrid[row, 0].View = m_HeaderView;
			hdr.RowSpan = 3;
		}

		/// <summary>
		/// �N���w���C�R���A�M�᭫�s�W�[�]���J�^�@�C�C
		/// </summary>
		/// <param name="row">�C���ޡC</param>
		private void RecreateRow(int row)
		{
			row = GetBrailleRowIndex(row);  // �ץ��C���ެ��I�r�C�Ҧb�����ޡC

			brGrid.Rows.RemoveRange(row, 3);

			GridInsertRowAt(row);

			if (ViewMode == ViewMode.BrailleOnly)
			{
				brGrid.Rows.HideRow(row + 1);
				brGrid.Rows.HideRow(row + 2);
			}
			else if (ViewMode == ViewMode.TextAndZhuyin)
			{
				brGrid.Rows.HideRow(row);
			}
		}


		/// <summary>
		/// �N BrailleDocument ��󤺮e��J grid�C
		/// </summary>
		/// <param name="brDoc">BrailleDocument ���C</param>
		private void FillGrid(BrailleDocument brDoc)
		{
			if (brDoc.Lines.Count < 1)
			{
				return;
			}

			int cnt = 0;
			StatusText = "���b�ǳ���ܸ��...";
			StatusProgress = 0;
			CursorHelper.ShowWaitCursor();
			brGrid.SuspendLayout();
			try
			{
				int row = DualEditForm.FixedRows;
				foreach (BrailleLine brLine in brDoc.Lines)
				{
					FillRow(brLine, row, false);    // ��@�C�A�����n�վ�C���C

					// ��S����ƪ��x�s���J�ťզr���C
					//for (int x = col; x < maxWordCount; x++)
					//{
					//    brGrid[row, x] = new SourceGrid.Cells.Cell(" ");
					//    brGrid[row, x].View = brView;
					//    brGrid[row, x].Editor = txtEditor;
					//    brGrid[row + 1, x] = new SourceGrid.Cells.Cell(" ");
					//    brGrid[row + 1, x].View = mingView;
					//    brGrid[row + 1, x].Editor = txtEditor;
					//    brGrid[row + 2, x] = new SourceGrid.Cells.Cell(" ");
					//    brGrid[row + 2, x].View = phonView;
					//    brGrid[row + 2, x].Editor = txtEditor;
					//}

					row += 3;

					cnt++;
					StatusProgress = cnt * 100 / brDoc.Lines.Count;
				}
			}
			finally
			{
				StatusText = "���s�վ��x�s��j�p...";
				ResizeCells();
				brGrid.ResumeLayout();
				StatusProgress = 0;
				CursorHelper.RestoreCursor();
			}
		}

		/// <summary>
		/// ��@�C�I�r��J���w�� grid �C�]�v�T�T�C�^�C
		/// </summary>
		/// <param name="brLine">�I�r��C�C</param>
		/// <param name="row">����J grid �������@�C�C</param>
		/// <param name="autoSize">�񧹤���A�O�_�n�۰ʭ��s�վ��x�s��j�p�C</param>
		private void FillRow(BrailleLine brLine, int row, bool autoSize)
		{
			string brFontText;
			int col = brGrid.FixedColumns;

			// �T�O�C���ެO�I�r�Ҧb���C�C
			row = GetBrailleRowIndex(row);

			brGrid.SuspendLayout();
			try
			{
				foreach (BrailleWord brWord in brLine.Words)
				{
					// �B�z�I�r
					try
					{
						if (brWord.IsContextTag)
						{
							brFontText = " ";
						}
						else
						{
							brFontText = BrailleFontConverter.ToString(brWord);
						}
					}
					catch (Exception e)
					{
						MsgBoxHelper.ShowError(e.Message + "\r\n" +
							"�C:" + row.ToString() + ", ��: " + col.ToString());
						brFontText = "";
					}

					brGrid[row, col] = new SourceGrid.Cells.Cell(brFontText);
					brGrid[row, col].ColumnSpan = brFontText.Length;
					brGrid[row, col].View = m_BrView;
					brGrid[row, col].Tag = brWord;
					brGrid[row, col].AddController(m_MenuController);
					brGrid[row, col].AddController(m_ClickController);

					// �B�z�����r
					brGrid[row + 1, col] = new SourceGrid.Cells.Cell(brWord.Text);
					brGrid[row + 1, col].ColumnSpan = brFontText.Length;
					brGrid[row + 1, col].View = m_MingView;					
					brGrid[row + 1, col].Tag = brWord;
					brGrid[row + 1, col].AddController(m_MenuController);
					brGrid[row + 1, col].AddController(m_ClickController);

					// �B�z�`���X
					brGrid[row + 2, col] = new SourceGrid.Cells.Cell(brWord.PhoneticCode);
					brGrid[row + 2, col].ColumnSpan = brFontText.Length;
					if (brWord.PhoneticCodes.Count > 1)
					{
						if (AppGlobals.Options.ErrorProneWords.IndexOf(brWord.Text) >= 0)
						{
							// �e���P�_���~���}���r���㲴������ХܡC
							brGrid[row + 2, col].View = m_PhonView3;
						}
						else
						{
							// �@��}���r�ζ���ХܡC
							brGrid[row + 2, col].View = m_PhonView2;
						}
					}
					else
					{
						brGrid[row + 2, col].View = m_PhonView;
					}
					brGrid[row + 2, col].Tag = brWord;

					col += brFontText.Length;
				}
			}
			finally
			{
				brGrid.Rows.AutoSizeRow(row);
				brGrid.Rows.AutoSizeRow(row + 1);
				brGrid.Rows.AutoSizeRow(row + 2);

				brGrid.ResumeLayout();
			}
		}

		/// <summary>
		/// Grid popup menu �I���ƥ�B�̱`���C
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void GridMenu_Click(object sender, SourceGrid.CellContextEventArgs e)
		{
			PopupMenuController menuCtrl = (PopupMenuController)sender;
			SourceGrid.CellContext cell = e.CellContext;
			SourceGrid.Grid grid = (SourceGrid.Grid)cell.Grid;
			int row = cell.Position.Row;
			int col = cell.Position.Column;

			switch (menuCtrl.Command)
			{
				case "Edit":
					EditCell(grid, row, col);
					break;
				case "Insert":
					InsertCell(grid, row, col);
					break;
				case "InsertBlank":  // ���J�Ť�                        
					InsertBlankCell(grid, row, col, 1);
					break;
				case "Append":  // �b�C�����J�Ť�
					AppendCell(grid, row, col);
					break;
				case "InsertLine":  // ���J�@�C
					InsertLine(grid, row, col);
					break;
				case "Delete":
					DeleteCell(grid, row, col);
					break;
				case "Backspace":
					BackspaceCell(grid, row, col);
					break;
				case "DeleteLine":
					DeleteLine(grid, row, col, true);
					break;
				default:
					break;
			}
		}

		/// <summary>
		/// �ˬd�x�s���m�O�_���ġC
		/// </summary>
		/// <param name="row"></param>
		/// <param name="col"></param>
		/// <returns></returns>
		private bool CheckCellPosition(int row, int col)
		{
			if (row < 0 || col < 0)
			{
				if (brGrid.RowsCount > brGrid.FixedRows && brGrid.ColumnsCount > brGrid.FixedColumns)
				{
					// Grid ����ƮɡA�~�i�D user �n�I���x�s��C
					MessageBox.Show("�Х��I���x�s��!");
				}
				return false;
			}
			return true;
		}

		/// <summary>
		/// ���s��C���C
		/// </summary>
		private void RefreshRowNumbers()
		{
			int rowNum = 1;
			int linesPerPage = AppGlobals.Options.LinesPerPage;

			if (AppGlobals.Options.PrintPageFoot)
			{
				linesPerPage--; // ���X���@�C�A�ҥH�C����ڪ��I�r�C�Ƥ֤@�C�C
			}

			for (int row = 1; row < brGrid.RowsCount; row += 3)
			{
				if ((rowNum - 1) % linesPerPage == 0)
				{
					brGrid[row, 0].View = m_HeaderView2;
					brGrid[row, 0].Value = rowNum;
				}
				else
				{
					brGrid[row, 0].View = m_HeaderView;
					brGrid[row, 0].Value = rowNum;
				}
				rowNum++;
			}
		}

		/// <summary>
		/// ���/����������w���C
		/// </summary>
		/// <param name="row">�C���ޡC</param>
		/// <param name="select">�O�_����C</param>
		private void GridSelectRow(int row, bool select)
		{
			row = GetBrailleRowIndex(row);
			SourceGrid.Range range = new SourceGrid.Range(row, brGrid.FixedColumns, row + 2, brGrid.ColumnsCount);
			brGrid.Selection.SelectRange(range, select);
		}

		/// <summary>
		/// �]�w�Y���x�s�欰 active cell�C
		/// </summary>
		/// <param name="pos">�x�s���m�C</param>
		/// <param name="resetSelection">�O�_�M������d��C</param>
		/// <returns></returns>
		private bool GridFocusCell(SourceGrid.Position pos, bool resetSelection)
		{
			if (pos.Row >= brGrid.RowsCount)
				return false;
			if (pos.Column >= brGrid.ColumnsCount)
				return false;
			brGrid.Selection.SelectCell(pos, true);
			return brGrid.Selection.Focus(pos, resetSelection);
		}

		/// <summary>
		/// ��s���w���I�r���C
		/// </summary>
		/// <param name="row"></param>
		/// <param name="col"></param>
		/// <param name="brWord"></param>
		private void UpdateCell(int row, int col, BrailleWord brWord)
		{
			// �B�z�I�r
			string brFontText = null;
			try
			{
				if (brWord.IsContextTag)
				{
					brFontText = " ";
				}
				else
				{
					brFontText = BrailleFontConverter.ToString(brWord);
				}
			}
			catch (Exception e)
			{
				MsgBoxHelper.ShowError(e.Message + "\r\n" +
					"�C:" + row.ToString() + ", ��: " + col.ToString());
				brFontText = "";
			}

			row = GetBrailleRowIndex(row);  // �T�O�C���ެ��I�r�C�C

			//�Y�C�� cell �@���I�r�A�N�ΥH�U�j���J�I�r
			//for (int i = 0; i < brFontText.Length; i++)
			//{
			//    brGrid[row, col+i].Value = brFontText[i];
			//}
			brGrid[row, col].Value = brFontText;
			brGrid[row, col].Tag = brWord;

			brGrid[row + 1, col].Value = brWord.Text;
			brGrid[row + 1, col].Tag = brWord;

			brGrid[row + 2, col].Value = brWord.PhoneticCode;
			brGrid[row + 2, col].Tag = brWord;
		}

		/// <summary>
		/// ���`���X�� ComboBox �U�Ԯ�Ĳ�o���ƥ�C
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void PhoneticComboBox_DropDown(object sender, EventArgs e)
		{
			//DevAgeComboBox cbo = (DevAgeComboBox)sender;
			//SourceGrid.Grid grid = (SourceGrid.Grid)cbo.Parent;
			//SourceGrid.Cells.ICell cell = (SourceGrid.Cells.ICell) grid.GetCell(grid.Selection.ActivePosition);
			//BrailleWord brWord = (BrailleWord)cell.Tag;

			//cbo.Items.Clear();
			//foreach (string s in brWord.CandidatePhoneticCodes)
			//{
			//    cbo.Items.Add(s);
			//}


			//if (brWord.CandidatePhoneticCodes.Count > 1)    // �}���r�H
			//{

			//}
			//else
			//{
			//    cbo.Items.Add(cbo.Text);
			//}

		}

		private void miFileOpen_Click(object sender, EventArgs e)
		{
			DoOpenFile();
		}

		private void miFileSaveAs_Click(object sender, EventArgs e)
		{
			DoSaveFileAs();
		}

		private void miFileSave_Click(object sender, EventArgs e)
		{
			DoSaveFile();
		}

		private void miFilePrint_Click(object sender, EventArgs e)
		{
			DoPrint();
		}


		private void cboZoom_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (cboZoom.SelectedIndex < 0)
				return;
			string s = cboZoom.Items[cboZoom.SelectedIndex].ToString();
			s = s.Substring(0, s.Length - 1);
			Zoom(Convert.ToInt32(s));
		}

		private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
		{
			if (e.ClickedItem.Tag == null)
				return;

			string s = e.ClickedItem.Tag.ToString();

			switch (s)
			{
				case "Open":
					DoOpenFile();
					break;
				case "Save":
					DoSaveFile();
					break;
				case "Print":
					DoPrint();
					break;
				default:
					break;
			}
		}

		/// <summary>
		/// �˵��Ҧ��G�u����I�r�C
		/// </summary>
		private void ViewBrailleOnly()
		{
			MsgBoxHelper.ShowWarning("�`�N! �������ե\��A�Y�o�{������D�A�Ф��^�w�]�Ҧ�:\n" +
				"�q�D����I��u�˵� > �Ҧ� > ��ܥ����v�C");

			int row;

			brGrid.SuspendLayout();
			CursorHelper.ShowWaitCursor();
			try
			{
				for (row = 1; row < brGrid.RowsCount; row += 3)
				{
					brGrid.Rows.HideRow(row + 1);
					brGrid.Rows.HideRow(row + 2);
				}
				miViewBrailleOnly.Checked = true;
				miViewTextZhuyin.Checked = false;
				miViewAll.Checked = false;
			}
			finally
			{
				brGrid.ResumeLayout();
				ResizeCells();
				CursorHelper.RestoreCursor();
			}
		}

		/// <summary>
		/// �˵��Ҧ��G��ܩ����r�Ϊ`���C
		/// </summary>
		private void ViewTextAndZhuyin()
		{
			int row;

			brGrid.SuspendLayout();
			CursorHelper.ShowWaitCursor();
			try
			{
				for (row = 1; row < brGrid.RowsCount; row += 3)
				{
					brGrid.Rows.HideRow(row);
				}
				miViewTextZhuyin.Checked = true;
				miViewBrailleOnly.Checked = false;
				miViewAll.Checked = false;
			}
			finally
			{
				brGrid.ResumeLayout();
				ResizeCells();
				CursorHelper.RestoreCursor();
			}
		}

		/// <summary>
		/// �˵��Ҧ��G��ܥ����C
		/// </summary>
		private void ViewAll()
		{
			int row;

			brGrid.SuspendLayout();
			CursorHelper.ShowWaitCursor();
			try
			{
				for (row = 1; row < brGrid.RowsCount; row += 3)
				{
					brGrid.Rows.ShowRow(row);
					brGrid.Rows.ShowRow(row + 1);
					brGrid.Rows.ShowRow(row + 2);
					brGrid.Rows.AutoSizeRow(row);
					brGrid.Rows.AutoSizeRow(row + 1);
					brGrid.Rows.AutoSizeRow(row + 2);
				}
				miViewAll.Checked = true;
				miViewBrailleOnly.Checked = false;
				miViewTextZhuyin.Checked = false;
			}
			finally
			{
				brGrid.ResumeLayout();
				ResizeCells();
				CursorHelper.RestoreCursor();
			}
		}

		private void miViewMode_Click(object sender, EventArgs e)
		{
			ToolStripMenuItem mi = sender as ToolStripMenuItem;
			switch (mi.Tag.ToString())
			{
				case "All":
					ViewMode = ViewMode.All;
					break;
				case "BrailleOnly":
					ViewMode = ViewMode.BrailleOnly;
					break;
				case "TextAndZhuyin":
					ViewMode = ViewMode.TextAndZhuyin;
					break;
			}
		}

		private void DualEditForm_KeyPress(object sender, KeyPressEventArgs e)
		{
			int row;
			int col;

			switch (e.KeyChar)
			{
				case ' ':   // �ť���G���J�@�ӪŤ�C
					row = brGrid.Selection.ActivePosition.Row;
					col = brGrid.Selection.ActivePosition.Column;
					InsertBlankCell(brGrid, row, col, 1);
					e.Handled = true;
					break;
				case '\r':
					row = brGrid.Selection.ActivePosition.Row;
					col = brGrid.Selection.ActivePosition.Column;
					BreakLine(brGrid, row, col);
					e.Handled = true;
					break;
			}
		}

		private void DualEditForm_KeyDown(object sender, KeyEventArgs e)
		{
			int row = brGrid.Selection.ActivePosition.Row;
			int col = brGrid.Selection.ActivePosition.Column;

			if (e.Modifiers == Keys.Control)
			{
				switch (e.KeyCode)
				{
					case Keys.I:        // Ctrl+I: �s�W�I�r�C
						InsertCell(brGrid, row, col);
						e.Handled = true;
						break;
					case Keys.Insert:    // Ctrl+Ins: �s�W�@�C�C
						InsertLine(brGrid, row, col);
						e.Handled = true;
						break;
					case Keys.Delete:   // Ctrl+Delete: �R���@���I�r�C
						DeleteCell(brGrid, row, col);
						e.Handled = true;
						break;
					case Keys.E:        // Ctrl+E: �R���@�C�C
						DeleteLine(brGrid, row, col, true);
						e.Handled = true;
						break;
				}
			}
		}


		private void EditPageTitles()
		{
			DualEditTitleForm fm = new DualEditTitleForm(m_BrDoc);
			fm.CellsPerLine = m_BrDoc.CellsPerLine;
			if (fm.ShowDialog() == DialogResult.OK)
			{
				m_BrDoc.PageTitles.Clear();
				m_BrDoc.PageTitles = fm.Titles;
			}
		}

		private void FetchPageTitles()
		{
			m_BrDoc.FetchPageTitles();
		}

		/// <summary>
		/// ����w���C�C
		/// <param name="lineNumber">�C��</param>
		/// </summary>
		private void GotoLine(int lineNum)
		{
			if (lineNum > m_BrDoc.LineCount)
			{
				lineNum = m_BrDoc.LineCount;
			}
			SourceGrid.Position pos = new SourceGrid.Position((lineNum - 1) * 3 + 1, 1);
			brGrid.ShowCell(pos, false);
		}

		/// <summary>
		/// ����w�����C
		/// <param name="pageNum">����</param>
		/// </summary>
		private void GotoPage(int pageNum)
		{
			if (pageNum < 1) 
			{
				pageNum = 1;
			}
			int lineNum = (pageNum - 1) * (AppGlobals.Options.LinesPerPage - 1)+ 1;

			GotoLine(lineNum);
		}

		private void Goto()
		{
			DualEditGotoForm fm = new DualEditGotoForm();
			if (fm.ShowDialog() == DialogResult.OK)
			{
				if (fm.IsGotoLine)
				{
					GotoLine(fm.Position);
				}
				else
				{
					GotoPage(fm.Position);
				}
			}
		}

		private void Find()
		{
			m_FindForm.Document = m_BrDoc;

			if (m_FindForm.Visible)
			{
				m_FindForm.BringToFront();
			}
			else
			{
				m_FindForm.Show();
			}
		}

		private void FindNext()
		{
			if (!m_FindForm.FindNext())
			{
				MsgBoxHelper.ShowInfo("�w�j�M�ܤ�󵲧��C");
			}
		}

		private void miEdit_Click(object sender, EventArgs e)
		{
			string s = (string)(sender as ToolStripMenuItem).Tag;
			switch (s)
			{
				case "PageTitles":
					EditPageTitles();
					break;
				case "FetchPageTitles":
					FetchPageTitles();
					break;
				case "Goto":
					Goto();
					break;
				case "Find":
					Find();
					break;
				case "FindNext":
					FindNext();
					break;
				default:
					break;
			}
		}

		private void btnGotoPage_Click(object sender, EventArgs e)
		{
			try
			{
				int pageNum = Convert.ToInt32(txtGotoPageNum.Text);
				GotoPage(pageNum);
			}
			catch
			{
				MsgBoxHelper.ShowError("�������ݿ�J���!");
			}
		}

		private void DualEditForm_FormClosed(object sender, FormClosedEventArgs e)
		{
			if (m_FindForm != null)
			{
				m_FindForm.DecidingStartPosition -= new DualEditFindForm.DecideStartPositionEvent(FindForm_DecidingStartPosition);
				m_FindForm.TargetFound -= new DualEditFindForm.TargetFoundEvent(FindForm_TargetFound);
				m_FindForm.Dispose();
			}
		}

		private void DualEditForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			e.Cancel = false;

			if (this.IsDirty || this.IsNoName())
			{
				string s = "�I�r��Ʃ|���x�s�A�O�_�x�s�H" + Environment.NewLine + Environment.NewLine +
					"[�O]�@ = �x�s�������������C" + Environment.NewLine +
					"[�_]�@ = ���x�s�������������C" + Environment.NewLine +
					"[����] = ���������������ʧ@�A�~��s���I�r�C";
				
				DialogResult result = MsgBoxHelper.ShowYesNoCancel(s);
				if (result == DialogResult.Cancel)
				{
					e.Cancel = true;
					return;
				}
				if (result == DialogResult.Yes)
				{
					if (!DoSaveFile())
					{
						e.Cancel = true;
					}
				}
			}
		}
	}


	public class CellClickEvent : SourceGrid.Cells.Controllers.ControllerBase
	{
		private DualEditForm m_Form;

		public CellClickEvent(DualEditForm form)
		{
			m_Form = form;
		}

		public override void OnClick(SourceGrid.CellContext sender, EventArgs e)
		{
			base.OnClick(sender, e);

			// ��ܥثe�J�I�Ҧb���x�s���ݩ�ĴX���C
			SourceGrid.Grid grid = (SourceGrid.Grid)sender.Grid;
			int row = sender.Position.Row;

			if (row < 1)
				return;

			int lineIdx = m_Form.GetBrailleLineIndex(row);
			int linesPerPage = AppGlobals.Options.LinesPerPage;
			bool needPageFoot = AppGlobals.Options.PrintPageFoot;
			int currPage = AppGlobals.CalcCurrentPage(lineIdx, linesPerPage, needPageFoot) + 1;
			int totalPages = AppGlobals.CalcTotalPages(m_Form.BrailleDoc.Lines.Count, linesPerPage, needPageFoot);
			m_Form.PageNumberText = currPage.ToString() + "/" + totalPages.ToString();


			//if (m_Form.DebugMode)
			//{
			//    SourceGrid.Grid grid = (SourceGrid.Grid)sender.Grid;
			//    int row = sender.Position.Row;
			//    int col = sender.Position.Column;

			//    BrailleWord brWord = (BrailleWord)grid[row, col].Tag;
			//    string brScreenText = brWord.CellList.ToString();
			//    string brPrinterText = BrailleGlobals.FontConvert.ToString(brWord);

			//    m_Form.StatusBar.Items[0].Text = brWord.Text +
			//        "(" + brScreenText + ") " + // ��ܮɪ��I�r 16 �i��r��
			//        "[" + brPrinterText + "]";  // �C�L�ɪ��I�r 16 �i��r��
			//}
		}
	}

}