﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace EasyBrailleEdit
{
	public partial class RemindTrialForm : Form
	{
		public RemindTrialForm()
		{
			InitializeComponent();
		}

		private void RemindTrialForm_Load(object sender, EventArgs e)
		{
			label1.Text = label1.Text.Replace("%1", FeatureLimit.MaxPrintPage.ToString());
		}


		private void AskRegForm_FormClosed(object sender, FormClosedEventArgs e)
		{
			AppConfig.Self.DontRemindTrialLimits = chkDontAskMeAgain.Checked;
			AppConfig.Self.Save();
		}

	}
}
