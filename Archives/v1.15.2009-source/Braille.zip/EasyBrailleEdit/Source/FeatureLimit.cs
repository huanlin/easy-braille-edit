﻿using System;
using System.Collections.Generic;
using System.Text;
using Huanlin.AppBlock.Registration;

namespace EasyBrailleEdit
{
	/// <summary>
	/// 控制版本功能差異
	/// </summary>
	public class FeatureLimit
	{
		public const int DefaultTrialMaxPage = 5;
		public const int DefaultPersonalMaxPage = 20;

		public static int MaxPrintPage = DefaultTrialMaxPage;	// 預設最多只能印幾頁
		public static bool StampTrialOnPrint = true;			// 列印時輸出試用版字樣

		private FeatureLimit() { }

		public static void RemoveAllLimits()
		{
			FeatureLimit.MaxPrintPage = 9999999;
			FeatureLimit.StampTrialOnPrint = false;
		}

		/// <summary>
		/// 設定試用版的功能限制。
		/// </summary>
		public static void SetTrialLimits()
		{
			FeatureLimit.MaxPrintPage = DefaultTrialMaxPage;
			FeatureLimit.StampTrialOnPrint = true;
		}

		/// <summary>
		/// 設定個人版的功能限制。
		/// </summary>
		public static void SetPersonalLimits()
		{
			FeatureLimit.MaxPrintPage = DefaultPersonalMaxPage;
			FeatureLimit.StampTrialOnPrint = false;
		}

		public static void LimitByVersion(string verName)
		{
			if (String.IsNullOrEmpty(verName))
			{
				SetTrialLimits();
				return;
			}

			verName = verName.ToUpper();

			if (ProductVersionName.IsProfessionalOrEnterprise(verName))	// 企業版或專業版
			{
				RemoveAllLimits();
				return;
			}

			if (ProductVersionName.IsPersonal(verName))	// 個人版
			{
				SetPersonalLimits();
				return;
			}

			SetTrialLimits();
		}
	}
}
