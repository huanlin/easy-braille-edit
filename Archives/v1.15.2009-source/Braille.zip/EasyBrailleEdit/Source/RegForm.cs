﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Configuration;
using System.Security.Cryptography;
using Huanlin.Helpers;
using Huanlin.WinForms;
using Huanlin.Sys;
using Huanlin.Collections;
using Huanlin.Cryptography;
using Huanlin.Text;

namespace EasyBrailleEdit
{
    public partial class RegForm : Form
    {
        private string m_ProductID;

        public RegForm()
        {
            InitializeComponent();
        }

        private void RegForm_Load(object sender, EventArgs e)
        {
            m_ProductID = AppConst.ProductID;
        }

        private void btnReg_Click(object sender, EventArgs e)
        {
            if (!SysInfo.IsNetworkConnected())
            {
                MsgBoxHelper.ShowError("您的電腦尚未連接至網際網路!");
                return;
            }

			if (!AppGlobals.ServeConnectable)
			{
				MsgBoxHelper.ShowError("無法連接伺服器: " + AppConfig.Self.AppServerName);
				return;
			}

            txtCustomerName.Text = txtCustomerName.Text.Trim();
            txtTel.Text = txtTel.Text.Trim();
            txtAddress.Text = txtAddress.Text.Trim();

            if (String.IsNullOrEmpty(txtCustomerName.Text))
            {
                MsgBoxHelper.ShowInfo("請輸入公司／組織名稱!");
                txtCustomerName.Focus();
                return;
            }

            string licenseKey = txtLicenseKey.Text.Trim().Replace("-", "");

            CursorHelper.ShowWaitCursor();
            try
            {
                ProductService.LicenseManager ws = new ProductService.LicenseManager();
				ws.Url = "http://" + AppConfig.Self.AppServerName + "/ProductService/LicenseManager.asmx";

                string regText = ws.RegisterUserEx(m_ProductID, licenseKey,
                    txtCustomerName.Text, txtContactName.Text, txtEmail.Text, txtTel.Text, txtAddress.Text.Trim());

                if (!String.IsNullOrEmpty(regText) && !regText.StartsWith("Error", StringComparison.CurrentCultureIgnoreCase))
                {
                    SaveRegData(regText);
					MsgBoxHelper.ShowInfo("註冊成功！");

					//if (MsgBoxHelper.ShowYesNo("註冊成功！應用程式必須重新啟動才能生效，是否立即重新啟動？") == DialogResult.Yes)
					//{
					//    FileRunner fn = new FileRunner();
					//    fn.NeedWait = false;
					//    fn.ShowWindow = true;
					//    fn.WindowStyle = System.Diagnostics.ProcessWindowStyle.Maximized;
					//    fn.UseShellExecute = false;
					//    fn.RedirectStandardOutput = false;
					//    fn.Run(Application.ExecutablePath, "");

					//    Close();
					//    Application.Exit();
					//    return;
					//}
                    this.DialogResult = DialogResult.OK;
                    Close();
                }
                else
                {
					if (regText.StartsWith("Error", StringComparison.CurrentCultureIgnoreCase))
					{
						MsgBoxHelper.ShowError(regText);
					}
					else
					{
						MsgBoxHelper.ShowInfo("註冊失敗!");
					}
                }
                CursorHelper.ResetToDefault();
            }
            catch (Exception ex)
            {
                CursorHelper.ResetToDefault();
                MsgBoxHelper.ShowError("註冊失敗!\r\n" + ex.Message);
            }
        }

        private void SaveRegData(string text)
        {
            string path = StrHelper.ExtractFilePath(Application.ExecutablePath);

            using (StreamWriter sw = new StreamWriter(path + AppGlobals.GetRegFileName(), false, Encoding.Default))
            {
                sw.Write(text);
                sw.Flush();
                sw.Close();
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.No;
            Close();
        }

        private void txtEmail_Enter(object sender, EventArgs e)
        {
            if (txtEmail.Text.IndexOf("電子郵件") >= 0)
            {
                txtEmail.Text = "";
            }
        }

        private void txtEmail_Leave(object sender, EventArgs e)
        {
            if (txtEmail.Text.Trim().Length == 0)
            {
                txtEmail.Text = "請填寫正確的電子郵件位址";
            }
        }
    }
}