﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing.Printing;

namespace EasyBrailleEdit
{
	// 雙面列印效果
	public enum DoubleSideEffect
	{
		None,
		OddPages,
		EvenPages
	}

	/// <summary>
	/// 列印選項。
	/// </summary>
	public class PrintOptions
	{
		// 列印範圍
		private bool m_AllPages;    // 列印全部？
		private int m_FromPage;
		private int m_ToPage;

		private int m_linesPerPage;             // 每頁列數
		private bool m_DoubleSide;              // 是否採雙面列印？
		private bool m_PrintPageFoot;           // 是否要列印頁尾？
		private bool m_ReassignStartPageNumber;	// 是否重新指定起始頁碼？
		private int m_StartPageNumber;          // 起始頁碼。
		private DoubleSideEffect m_DoubleSideEffect;    // 手動雙面列印選項

		private string m_PrinterName;
		private string m_PaperSourceName;   // 紙張來源
		private string m_PaperName;
		private Margins m_OddPageMargins;
		private Margins m_EvenPageMagins;


		public PrintOptions() : base()
		{
			m_AllPages = true;
			m_FromPage = 0;
			m_ToPage = 0;
			m_DoubleSide = false;
			m_PrintPageFoot = true;
			m_ReassignStartPageNumber = false;
			m_StartPageNumber = 1;
			m_linesPerPage = AppConst.DefaultLinesPerPage;
			m_DoubleSideEffect = DoubleSideEffect.None;

			m_PaperSourceName = "";
			m_PaperName = "custom";

			m_OddPageMargins = new Margins();
			m_EvenPageMagins = new Margins();
		}

		/// <summary>
		/// 起始頁數。
		/// </summary>
		public int FromPage
		{
			get { return m_FromPage; }
			set
			{
				if (value < 1)
					throw new ArgumentException("起始頁數不可小於 1。");
				m_FromPage = value;
			}
		}

		/// <summary>
		/// 終止頁數。
		/// </summary>
		public int ToPage
		{
			get { return m_ToPage; }
			set
			{
				if (value < 1)
					throw new ArgumentException("終止頁數不可小於 1。");
				m_ToPage = value;
			}
		}

		/// <summary>
		/// 檢查列印範圍是否有效。
		/// </summary>
		public void CheckRange()
		{
			if (m_AllPages)
				return;
			if (m_ToPage < m_FromPage)
				throw new ArgumentException("終止頁數不可小於起始頁數!");
		}

		public bool AllPages
		{
			get { return m_AllPages; }
			set { m_AllPages = value; }
		}

		public int LinesPerPage
		{
			get { return m_linesPerPage; }
			set { m_linesPerPage = value; }
		}

		public bool DoubleSide
		{
			get { return m_DoubleSide; }
			set { m_DoubleSide = value; }
		}

		public bool PrintPageFoot
		{
			get { return m_PrintPageFoot; }
			set { m_PrintPageFoot = value; }
		}

		public int StartPageNumber
		{
			get { return m_StartPageNumber; }
			set { m_StartPageNumber = value; }
		}

		public DoubleSideEffect DoubleSideEffect
		{
			get { return m_DoubleSideEffect; }
			set { m_DoubleSideEffect = value; }
		}

		public string PrinterName
		{
			get { return m_PrinterName; }
			set { m_PrinterName = value; }
		}

		public string PaperSourceName
		{
			get { return m_PaperSourceName; }
			set { m_PaperSourceName = value; }
		}

		public string PaperName
		{
			get { return m_PaperName; }
			set { m_PaperName = value; }
		}

		public Margins OddPageMargins
		{
			get { return m_OddPageMargins; }
			set { m_OddPageMargins = value; }
		}

		public Margins EvenPageMargins
		{
			get { return m_EvenPageMagins; }
			set { m_EvenPageMagins = value; }
		}

		public bool ReassignStartPageNumber
		{
			get { return m_ReassignStartPageNumber; }
			set { m_ReassignStartPageNumber = value; }
		}
	}
}
