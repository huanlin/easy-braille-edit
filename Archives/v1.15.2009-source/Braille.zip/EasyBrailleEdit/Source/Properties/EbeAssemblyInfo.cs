﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// 版本號碼的格式: [主版號].[次版號].[YMMDD].[Subversion revision number]
[assembly: AssemblyVersion("1.15.2009.1212")]
[assembly: AssemblyFileVersion("1.15.2009.1212")]
