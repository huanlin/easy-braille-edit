using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.ServiceProcess;
using System.Text;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;

namespace BrailleService
{
    public partial class BrailleService : ServiceBase
    {
        private IChannel mTcpChannel;

        public BrailleService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            // ���U�q�D
            mTcpChannel = new TcpChannel(9090);
            ChannelServices.RegisterChannel(mTcpChannel, false);

            // ���U���O
            Type svrType = typeof(Huanlin.Helpers.RemoteImmHelper);
            RemotingConfiguration.RegisterWellKnownServiceType(
                svrType, "RemoteImmHelper", WellKnownObjectMode.Singleton);       
        }

        protected override void OnStop()
        {
            ChannelServices.UnregisterChannel(mTcpChannel);
        }
    }
}
