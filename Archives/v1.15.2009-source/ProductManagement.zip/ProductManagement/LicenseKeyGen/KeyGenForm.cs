﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace LicenseKeyGen
{
    public partial class KeyGenForm : Form
    {
        public KeyGenForm()
        {
            InitializeComponent();
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            LicenseKey.GenerateKey keyGen = new LicenseKey.GenerateKey();

            keyGen.LicenseTemplate = "xxxx-xxxx-xxxx-xxxx";
            keyGen.MaxTokens = 0;
            keyGen.UseBase10 = false;
            keyGen.UseBytes = true;

			lbxKeys.Items.Clear();
            for (int i = 0; i < nud.Value; i++)
            {
                keyGen.CreateKey();
				lbxKeys.Items.Add(keyGen.GetLicenseKey());
            }
        }

		private void btnWriteToDB_Click(object sender, EventArgs e)
		{
			if (cboVersionName.SelectedIndex < 0) 
			{
				MessageBox.Show("請選擇版本!");
				return;
			}

			int cnt = 0;

			string cnstr = ConfigurationManager.ConnectionStrings["LicenseDB"].ConnectionString;
			using (SqlConnection cn = new SqlConnection(cnstr))
			{
				cn.Open();

				SqlCommand cmd = new SqlCommand();
				cmd.Connection = cn;

				foreach (string key in lbxKeys.Items)
				{					
					cmd.CommandText = "Insert into LicenseKeys (KeyValue, VersionName, ExpDate) values ('" + 
						key.Replace("-", "") + "', '" + cboVersionName.Text + "', '" + dateExpired.Value.ToString("yyyy-MM-dd") + "')";
					cnt += cmd.ExecuteNonQuery();
				}

				cn.Close();
			}
			MessageBox.Show("成功寫入 " + cnt.ToString() + " 筆");
			
		}

		private void lbxKeys_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (lbxKeys.SelectedIndex < 0)
			{
				txtSelectedKey.Text = "";
			}
			else
			{
				txtSelectedKey.Text = lbxKeys.Text;
				txtSelectedKey.SelectAll();
			}
		}

		private void cboVersionName_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (cboVersionName.SelectedIndex < 0)
				return;
			string ver = cboVersionName.Items[cboVersionName.SelectedIndex].ToString();
			switch (ver)
			{
				case "PRO":
				case "STD":
				case "ENT":
					dateExpired.Value = new DateTime(3000, 1, 1);
					break;
				case "TRI":
				case "CMU":
					dateExpired.Value = DateTime.Now.AddYears(1).AddMonths(1);
					break;
			}
		}
    }
}