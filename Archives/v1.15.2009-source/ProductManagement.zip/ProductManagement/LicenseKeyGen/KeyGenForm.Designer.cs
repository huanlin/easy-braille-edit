﻿namespace LicenseKeyGen
{
    partial class KeyGenForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.btnGenerate = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.nud = new System.Windows.Forms.NumericUpDown();
			this.btnWriteToDB = new System.Windows.Forms.Button();
			this.lbxKeys = new System.Windows.Forms.ListBox();
			this.dateExpired = new System.Windows.Forms.DateTimePicker();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.cboVersionName = new System.Windows.Forms.ComboBox();
			this.txtSelectedKey = new System.Windows.Forms.TextBox();
			((System.ComponentModel.ISupportInitialize)(this.nud)).BeginInit();
			this.SuspendLayout();
			// 
			// btnGenerate
			// 
			this.btnGenerate.Location = new System.Drawing.Point(185, 27);
			this.btnGenerate.Name = "btnGenerate";
			this.btnGenerate.Size = new System.Drawing.Size(63, 28);
			this.btnGenerate.TabIndex = 0;
			this.btnGenerate.Text = "Go!";
			this.btnGenerate.UseVisualStyleBackColor = true;
			this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(12, 29);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(111, 15);
			this.label1.TabIndex = 2;
			this.label1.Text = "產生幾組序號:";
			// 
			// nud
			// 
			this.nud.Location = new System.Drawing.Point(129, 27);
			this.nud.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
			this.nud.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.nud.Name = "nud";
			this.nud.Size = new System.Drawing.Size(50, 25);
			this.nud.TabIndex = 3;
			this.nud.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
			// 
			// btnWriteToDB
			// 
			this.btnWriteToDB.Location = new System.Drawing.Point(320, 188);
			this.btnWriteToDB.Name = "btnWriteToDB";
			this.btnWriteToDB.Size = new System.Drawing.Size(247, 53);
			this.btnWriteToDB.TabIndex = 4;
			this.btnWriteToDB.Text = "將全部序號寫入資料庫";
			this.btnWriteToDB.UseVisualStyleBackColor = true;
			this.btnWriteToDB.Click += new System.EventHandler(this.btnWriteToDB_Click);
			// 
			// lbxKeys
			// 
			this.lbxKeys.FormattingEnabled = true;
			this.lbxKeys.ItemHeight = 15;
			this.lbxKeys.Location = new System.Drawing.Point(12, 72);
			this.lbxKeys.Name = "lbxKeys";
			this.lbxKeys.Size = new System.Drawing.Size(236, 139);
			this.lbxKeys.TabIndex = 5;
			this.lbxKeys.SelectedIndexChanged += new System.EventHandler(this.lbxKeys_SelectedIndexChanged);
			// 
			// dateExpired
			// 
			this.dateExpired.Location = new System.Drawing.Point(367, 72);
			this.dateExpired.Name = "dateExpired";
			this.dateExpired.Size = new System.Drawing.Size(200, 25);
			this.dateExpired.TabIndex = 6;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(285, 77);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(71, 15);
			this.label2.TabIndex = 7;
			this.label2.Text = "有效期限";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(317, 121);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(39, 15);
			this.label3.TabIndex = 8;
			this.label3.Text = "版本";
			// 
			// cboVersionName
			// 
			this.cboVersionName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cboVersionName.FormattingEnabled = true;
			this.cboVersionName.Items.AddRange(new object[] {
            "CMU",
            "ENT",
            "PRO",
            "STD",
            "TRI"});
			this.cboVersionName.Location = new System.Drawing.Point(367, 115);
			this.cboVersionName.Name = "cboVersionName";
			this.cboVersionName.Size = new System.Drawing.Size(200, 23);
			this.cboVersionName.TabIndex = 9;
			this.cboVersionName.SelectedIndexChanged += new System.EventHandler(this.cboVersionName_SelectedIndexChanged);
			// 
			// txtSelectedKey
			// 
			this.txtSelectedKey.Location = new System.Drawing.Point(12, 216);
			this.txtSelectedKey.Name = "txtSelectedKey";
			this.txtSelectedKey.ReadOnly = true;
			this.txtSelectedKey.Size = new System.Drawing.Size(236, 25);
			this.txtSelectedKey.TabIndex = 10;
			// 
			// KeyGenForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(586, 267);
			this.Controls.Add(this.txtSelectedKey);
			this.Controls.Add(this.cboVersionName);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.dateExpired);
			this.Controls.Add(this.lbxKeys);
			this.Controls.Add(this.btnWriteToDB);
			this.Controls.Add(this.nud);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btnGenerate);
			this.Font = new System.Drawing.Font("MingLiU", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
			this.Margin = new System.Windows.Forms.Padding(4);
			this.Name = "KeyGenForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "序號產生器";
			((System.ComponentModel.ISupportInitialize)(this.nud)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

		private System.Windows.Forms.Button btnGenerate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown nud;
		private System.Windows.Forms.Button btnWriteToDB;
		private System.Windows.Forms.ListBox lbxKeys;
		private System.Windows.Forms.DateTimePicker dateExpired;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ComboBox cboVersionName;
		private System.Windows.Forms.TextBox txtSelectedKey;
    }
}

