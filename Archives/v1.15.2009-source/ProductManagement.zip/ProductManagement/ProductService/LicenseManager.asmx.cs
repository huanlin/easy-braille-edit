﻿using System;
using System.Data;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Text;
using System.Configuration;
using System.IO;
using System.Net;
using System.Net.Mail;
using Huanlin.Helpers;
using Huanlin.Collections;
using Huanlin.AppBlock.Registration;

namespace ProductService
{
    /// <summary>
    /// Summary description for LicenseManager
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [ToolboxItem(false)]
    public class LicenseManager : System.Web.Services.WebService
    {
		internal class RegFlag
		{
			public const char Insert = 'I';
			public const char Update = 'U';
			public const char Failed = 'F';
			public const char Pirate = 'P';
		}

		const string AppTitle = "Huanlin 軟體授權服務";
		const string ErrorMsgPrefix = "Error: ";

        private string m_ConnStr;
        private UserRegCrypto regCrypto;

		private string m_AdminEmail;	// 管理員信箱

		// SMTP 相關參數
		private string m_SmtpServer;
		private int m_SmtpPort;
		private bool m_SmtpSsl;
		private string m_SmtpSenderEmail;
		private bool m_SmtpNeedAuthenticate;
		private string m_SmtpUserName;
		private string m_SmtpPassword;

        public LicenseManager()
        {       
            m_ConnStr = ConfigurationManager.ConnectionStrings["HuanlinSoftConnStr"].ConnectionString;

			m_AdminEmail = ConfigurationManager.AppSettings["AdminEmail"];

			m_SmtpServer = ConfigurationManager.AppSettings["SmtpServer"];
			m_SmtpPort = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpPort"]);
			m_SmtpSsl = Convert.ToBoolean(ConfigurationManager.AppSettings["SmtpSsl"]);
			m_SmtpSenderEmail = ConfigurationManager.AppSettings["SmtpSenderEmail"];
			m_SmtpNeedAuthenticate = Convert.ToBoolean(ConfigurationManager.AppSettings["SmtpNeedAuthenticate"]);
			m_SmtpUserName = ConfigurationManager.AppSettings["SmtpUserName"];
			m_SmtpPassword = ConfigurationManager.AppSettings["SmtpPassword"];

            // 取得我的公鑰與私鑰。
            string publicKey;
            string privateKey;

            string path = Server.MapPath("~");
            using (StreamReader sr = new StreamReader(path + @"\PublicKey.xml")) 
            {
                publicKey = sr.ReadToEnd();
            }
            using (StreamReader sr = new StreamReader(path + @"\PrivateKey.xml"))
            {
                privateKey = sr.ReadToEnd();
            }

            regCrypto = new UserRegCrypto(publicKey, privateKey);
        }

		/// <summary>
		/// 寄送通知訊息給管理員。此函式不會丟出 exception，當有錯誤發生時，
		/// 訊息會寫入 Web 應用程式所在路徑的 LicenseManagerError.log 檔案。
		/// </summary>
		/// <param name="subject"></param>
		/// <param name="body"></param>
		private void SendAlertMail(string subject, StringBuilder body)
		{
			Encoding enc = Encoding.GetEncoding("BIG5");
			try
			{
				MailMessage msg = new MailMessage();
				msg.From = new MailAddress(m_SmtpSenderEmail, AppTitle, enc);
				msg.To.Add(m_AdminEmail);
				msg.IsBodyHtml = true;
				msg.Body = body.ToString();
				msg.Subject = subject;
				msg.SubjectEncoding = enc;

				SmtpClient smtp = new SmtpClient();
				smtp.Host = m_SmtpServer;
				smtp.Port = m_SmtpPort;
				smtp.EnableSsl = m_SmtpSsl;
				smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
				smtp.UseDefaultCredentials = false;
				if (m_SmtpNeedAuthenticate)
				{
					smtp.UseDefaultCredentials = true;
					NetworkCredential userCred = new NetworkCredential(m_SmtpUserName, m_SmtpPassword);
					smtp.Credentials = userCred;
				}

				smtp.Send(msg);
			}
			catch (Exception ex)
			{
				StringBuilder sb = new StringBuilder();
				sb.Append("寄送郵件失敗! Exception: ");
				sb.Append(Environment.NewLine);
				sb.Append(ex.ToString());
				sb.Append(Environment.NewLine);
				sb.Append(Environment.NewLine);
				sb.Append("信件標題：");
				sb.Append(Environment.NewLine);
				sb.Append(subject);
				sb.Append(Environment.NewLine);
				sb.Append("內文：");
				sb.Append(Environment.NewLine);
				sb.Append(body.ToString());

				string fname = Huanlin.Text.StrHelper.AppendSlash(Server.MapPath("~/")) + "LicenseManagerError.log";
				try
				{
					File.WriteAllText(fname, sb.ToString(), enc);
				}
				catch 
				{
					throw new Exception("伺服器端無法寫入檔案: LicenseManagerError.log。請聯絡程式開發人員!");
				}
			}
		}

		[WebMethod]
		public string GetClientIP()
		{
			string ip = HttpContext.Current.Request.UserHostAddress;
			return ip;
		}

		/// <summary>
		/// 比較兩個 IP 位址相符。
		/// </summary>
		/// <param name="ip1"></param>
		/// <param name="ip2"></param>
		/// <param name="onlyClassC">只比對 Class C，也就 IP 位址的前三個部分。</param>
		/// <returns></returns>
		private bool CompareIP(string ip1, string ip2, bool onlyClassC)
		{
			if (!IPAddressPattern.IsValidIPAddress(ip1) || !IPAddressPattern.IsValidIPAddress(ip2))
			{
				return false;
			}

			bool ipValid = false;
			if (onlyClassC)
			{
				// 只比對 IP 位址的 class C 部份。
				int i = ip1.LastIndexOf('.');
				if (ip2.StartsWith(ip1.Substring(0, i + 1)))
				{
					ipValid = true;
				}
			}
			else
			{
				// 比對完整的 IP 位址。
				ipValid = ip2.Equals(ip1);
			}
			return ipValid;
		}

		/// <summary>
		/// 驗證用戶端 IP 是否符合註冊的 IP 位址。
		/// 如果驗證失敗，會寄通知信件給管理員，並傳回 false。
		/// 注意：如果應用程式不需要鎖 IP 位址，就不要呼叫此方法。
		/// </summary>
		/// <param name="userRegDataStr">使用者註冊資料。</param>
		/// <returns></returns>
		[WebMethod]
		public bool ValidateUserReg(string userRegDataStr)
		{
			string userIP = GetClientIP();

			UserRegData reg;
			try
			{
				reg = UserRegData.Parse(userRegDataStr);
			}
			catch 
			{
				StringBuilder sb = new StringBuilder();
				sb.Append("LicenseManager.ValidateUserReg 方法無法解析使用者註冊資料：<BR/>");
				sb.Append(userRegDataStr);
				sb.Append("<BR/><BR/>用戶端 IP 位址: ");
				sb.Append(userIP);

				SendAlertMail(AppTitle  + "：無法解析使用者註冊資料!", sb);
					
				return false;
			}

			if (ProductVersionName.IsTrial(reg.VersionName))
			{
				// 試用版不比對 IP 位址。
				return true;
			}

			// 只有企業版和專業版要比對 class C。
			bool onlyClassC = false;
			if (ProductVersionName.IsProfessionalOrEnterprise(reg.VersionName))
			{
				onlyClassC = true;				
			}

			bool ipValid = false;

			/*
			 * 不檢查使用者註冊檔中記錄的 IP 位址，只比對用戶端 IP 位址是否和資料庫中的註冊 IP 位址相符，
			 * 因為使用者 IP 位址可能變更，這樣就可以在確認使用者合法的情況下，直接去資料庫中更改其註冊的
			 * IP 位址。
			 * 
			// 先比較使用者 IP 位址跟註冊資料的 IP 位址是否相符.
			ipValid = CompareIP(userIP, reg.IPAddr.ToString(), onlyClassC);
			if (!ipValid)
			{
				SendPirateNotification(reg, userIP);
				return false;
			}
			 */

			// 再到資料庫核對已註冊的資料中是否有這個 IP 位址。
			ipValid = IsIPAddressRegistered(userIP, onlyClassC);
			if (!ipValid)
			{
				SendPirateNotification(reg, userIP);
				return false;
			}

			return true;
		}

		/// <summary>
		/// 傳送疑似海盜通知給管理員。
		/// </summary>
		/// <param name="reg"></param>
		/// <param name="userIP"></param>
		private void SendPirateNotification(UserRegData reg, string userIP) 
		{
			StringBuilder sb = new StringBuilder();
			sb.Append("用戶端機器 IP 位址：");
			sb.Append(userIP);
			sb.Append("<BR/><BR/>使用者註冊資料：<BR/>");
			sb.Append("<BR/>User name:");
			sb.Append(reg.CustomerName);
			sb.Append("<BR/>Product ID: ");
			sb.Append(reg.ProductID);
			sb.Append("<BR/>Version: ");
			sb.Append(reg.VersionName);
			sb.Append("<BR/>License key: ");
			sb.Append(reg.LicenseKey);
			sb.Append("<BR/>原本註冊的 IP 位址: ");
			sb.Append(reg.IPAddr.ToString());
			sb.Append("<BR/>");

			string subject = AppTitle + "：偵測到使用者註冊資料檔與用戶端 IP 位址不符。";

			SendAlertMail(subject, sb);
		}

        [WebMethod]
        [ObsoleteAttribute("此函式已經過時", true)]
        public string RegisterUser(string productId, string licenseKey, 
            string customerName, string tel, string address)
        {
			string regData = DoRegisterUser(productId, licenseKey, customerName, tel, address);
			return regData;
        }

        /// <summary>
        /// 註冊使用者。若使用者已經註冊過，則忽略，並傳回空字串。
        /// 若 IP 位址不合法，則傳回
        /// </summary>
        /// <param name="productId">產品編號。</param>
        /// <param name="licenseKey">序號。</param>
        /// <param name="customerName">客戶名稱。</param>
        /// <param name="contactName">聯絡人。</param>
        /// <param name="email">E-mail</param>
        /// <param name="tel">電話。</param>
        /// <param name="address">地址。</param>
        /// <returns>如果成功，即傳回加密過的使用者資訊（使用 Base64 編碼），失敗時則傳回以 "錯誤" 開頭的訊息字串。</returns>
        [WebMethod]
        public string RegisterUserEx(string productId, string licenseKey,
            string customerName, string contactName, string email, string tel, string address)
        {
            string regData = DoRegisterUserEx(productId, licenseKey, customerName, contactName, email, tel, address);
            return regData;
        }

		/// <summary>
		/// 註冊使用者。若使用者已經註冊過，則忽略，並傳回空字串。
		/// 若 IP 位址不合法，則傳回
		/// </summary>
		/// <param name="productId">產品編號。</param>
		/// <param name="licenseKey">序號。</param>
		/// <param name="userName">使用者名稱。</param>
		/// <param name="tel">電話。</param>
		/// <param name="address">地址。</param>
		/// <returns>如果成功，即傳回加密過的使用者資訊（使用 Base64 編碼），失敗時則傳回以 "錯誤" 開頭的訊息字串。</returns>
		private string DoRegisterUser(string productId, string licenseKey,
			string userName, string tel, string address)
		{
			string ipString = HttpContext.Current.Request.UserHostAddress;
			IPAddress ipAddr = IPAddress.Parse(ipString);

			// 記錄目前要進行註冊的資料。
			UserRegData inputRegData = new UserRegData();
			inputRegData.ProductID = productId;
			inputRegData.LicenseKey = licenseKey;
			inputRegData.CustomerName = userName;
			inputRegData.Tel = tel;
			inputRegData.Address = address;
			inputRegData.IPAddr = ipAddr;

			string errMsg = null;

			// 檢查產品編號是否正確。
			if (!ProductExists(productId))
			{
				errMsg = ErrorMsgPrefix + "產品編號無效!";
				InsertUserRegLog(inputRegData, RegFlag.Failed, errMsg);  // 寫入註冊記錄，旗號為 "失敗"。
				return errMsg;
			}

			// 檢查序號是否有效。
			string versionName;
			DateTime expiredDate;

			if (!IsLicenseKeyValid(licenseKey, out versionName, out expiredDate))
			{
				errMsg = ErrorMsgPrefix + "序號無效或已過期!";
				InsertUserRegLog(inputRegData, RegFlag.Failed, errMsg);  // 寫入註冊記錄，旗號為 "失敗"。
				return errMsg;
			}

			// 檢查使用者是否已經註冊過。如果使用者已經註冊過，就不異動資料，只傳回加密的註冊資訊。
			UserRegData regData = GetUserRegData(productId, licenseKey);
			string encryptedRegData;

			if (regData == null)
			{
				// 尚未註冊過
				regData = new UserRegData();
				regData.ProductID = productId;
				regData.LicenseKey = licenseKey;
				regData.CustomerName = userName;
				regData.Tel = tel;
				regData.Address = address;
				regData.IPAddr = ipAddr;
				regData.VersionName = versionName;
				regData.ExpiredDate = expiredDate;

				// 加密並簽章。
				encryptedRegData = regCrypto.EncryptAndSign(regData);

				// 新增至資料庫。
				InsertUserReg(regData);
				InsertUserRegLog(regData, RegFlag.Insert, "");  // 寫入註冊記錄，旗號為 "新增成功"。
			}
			else
			{
				// 已經有註冊資料，檢查 IP 位址是否相符。				

				bool onlyClassC = false;	// 只有企業版和專業版要比對 class C。
				if (ProductVersionName.IsProfessionalOrEnterprise(regData.VersionName))
				{
					onlyClassC = true;
				}

				// 比較使用者 IP 位址跟註冊資料的 IP 位址是否相符.
				bool ipValid = CompareIP(ipString, regData.IPAddr.ToString(), onlyClassC);

				if (!ipValid)
				{
					errMsg = ErrorMsgPrefix + "註冊失敗! 序號已經註冊過。";

					// 用不同 IP 位址重複註冊，表示序號被海盜，故不允許註冊。
					InsertUserRegLog(inputRegData, RegFlag.Pirate, errMsg);  // 寫入註冊記錄，旗號為 "疑似海盜"。
					return errMsg;
				}

				// 加密並簽章。
				encryptedRegData = regCrypto.EncryptAndSign(regData);

				// 寫入註冊記錄，旗號為 "更新註冊"。
				InsertUserRegLog(inputRegData, RegFlag.Update, "");	// 寫入註冊記錄時，要用傳入的註冊資料
			}
			return encryptedRegData;
		}

        /// <summary>
        /// 註冊使用者。若使用者已經註冊過，則忽略，並傳回空字串。
        /// 若 IP 位址不合法，則傳回
        /// </summary>
        /// <param name="productId">產品編號。</param>
        /// <param name="licenseKey">序號。</param>
        /// <param name="customerName">客戶名稱。</param>
        /// <param name="contactName">聯絡人。</param>
        /// <param name="email">E-mail</param>
        /// <param name="tel">電話。</param>
        /// <param name="address">地址。</param>
        /// <returns>如果成功，即傳回加密過的使用者資訊（使用 Base64 編碼），失敗時則傳回以 "錯誤" 開頭的訊息字串。</returns>
        private string DoRegisterUserEx(string productId, string licenseKey,
            string customerName, string contactName, string email, string tel, string address)
        {
            string ipString = HttpContext.Current.Request.UserHostAddress;
            IPAddress ipAddr = IPAddress.Parse(ipString);

            // 記錄目前要進行註冊的資料。
            UserRegData inputRegData = new UserRegData();
            inputRegData.ProductID = productId;
            inputRegData.LicenseKey = licenseKey;
            inputRegData.CustomerName = customerName;
            inputRegData.ContactName = contactName;
            inputRegData.Email = email;
            inputRegData.Tel = tel;
            inputRegData.Address = address;
            inputRegData.IPAddr = ipAddr;

            string errMsg = null;

            // 檢查產品編號是否正確。
            if (!ProductExists(productId))
            {
                errMsg = ErrorMsgPrefix + "產品編號無效!";
                InsertUserRegLog(inputRegData, RegFlag.Failed, errMsg);  // 寫入註冊記錄，旗號為 "失敗"。
                return errMsg;
            }

            // 檢查序號是否有效。
            string versionName;
            DateTime expiredDate;

            if (!IsLicenseKeyValid(licenseKey, out versionName, out expiredDate))
            {
                errMsg = ErrorMsgPrefix + "序號無效或已過期!";
                InsertUserRegLog(inputRegData, RegFlag.Failed, errMsg);  // 寫入註冊記錄，旗號為 "失敗"。
                return errMsg;
            }

            // 檢查使用者是否已經註冊過。如果使用者已經註冊過，就不異動資料，只傳回加密的註冊資訊。
            UserRegData regData = GetUserRegData(productId, licenseKey);
            string encryptedRegData;

            if (regData == null)
            {
                // 尚未註冊過
                regData = new UserRegData();
                regData.ProductID = productId;
                regData.LicenseKey = licenseKey;
                regData.CustomerName = customerName;
                regData.ContactName = contactName;
                regData.Email = email;
                regData.Tel = tel;
                regData.Address = address;
                regData.IPAddr = ipAddr;
                regData.VersionName = versionName;
                regData.ExpiredDate = expiredDate;

                // 加密並簽章。
                encryptedRegData = regCrypto.EncryptAndSign(regData);

                // 新增至資料庫。
                InsertUserReg(regData);
                InsertUserRegLog(regData, RegFlag.Insert, "");  // 寫入註冊記錄，旗號為 "新增成功"。
            }
            else
            {
                // 已經有註冊資料，檢查 IP 位址是否相符。				

                bool onlyClassC = false;	// 只有企業版和專業版要比對 class C。
                if (ProductVersionName.IsProfessionalOrEnterprise(regData.VersionName))
                {
                    onlyClassC = true;
                }

                // 比較使用者 IP 位址跟註冊資料的 IP 位址是否相符.
                bool ipValid = CompareIP(ipString, regData.IPAddr.ToString(), onlyClassC);

                if (!ipValid)
                {
                    errMsg = ErrorMsgPrefix + "註冊失敗! 序號已經註冊過。";

                    // 用不同 IP 位址重複註冊，表示序號被海盜，故不允許註冊。
                    InsertUserRegLog(inputRegData, RegFlag.Pirate, errMsg);  // 寫入註冊記錄，旗號為 "疑似海盜"。
                    return errMsg;
                }

                // 加密並簽章。
                encryptedRegData = regCrypto.EncryptAndSign(regData);

                // 寫入註冊記錄，旗號為 "更新註冊"。
                InsertUserRegLog(inputRegData, RegFlag.Update, "");	// 寫入註冊記錄時，要用傳入的註冊資料
            }
            return encryptedRegData;
        }


        /// <summary>
        /// 新增使用者註冊記錄。
        /// </summary>
        private void InsertUserReg(UserRegData regData)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into UserReg (ProductID, LicenseKey, VersionName, IPAddress, CustomerName, ContactName, Email, Tel, Address, ExpDate)");
            sb.Append(" values ('");
            sb.Append(regData.ProductID + "', '");
            sb.Append(regData.LicenseKey + "', '");
			sb.Append(regData.VersionName + "', '");
            sb.Append(regData.IPAddr.ToString() + "', '");
            sb.Append(regData.CustomerName + "', '");
            sb.Append(regData.ContactName + "', '");
            sb.Append(regData.Email + "', '");
            sb.Append(regData.Tel + "', '");
            sb.Append(regData.Address + "', '");
			sb.Append(regData.ExpiredDate.ToString("yyyy-MM-dd") + "')");

            using (SqlConnection cn = new SqlConnection(m_ConnStr))
            {
                SqlCommand cmd = new SqlCommand(sb.ToString(), cn);
                cn.Open();
                cmd.ExecuteNonQuery();

                // 異動序號的使用旗號。
                cmd.CommandText = "update LicenseKeys set Used='true' where KeyValue='" +
                    regData.LicenseKey + "'";
                cmd.ExecuteNonQuery();

                cn.Close();
            }
        }

        /// <summary>
        /// 寫入註冊記錄檔，並且在新增註冊成功、註冊失敗、以及疑似海盜行為時發送發送 e-mail 通知管理員。
        /// </summary>
        /// <param name="regData"></param>
		/// <param name="regFlag">旗號, I=正常新增的註冊紀錄, U=更新註冊紀錄, F=失敗, P=疑似海盜。</param>
		/// <param name="msg">錯誤訊息。</param>
        private void InsertUserRegLog(UserRegData regData, char regFlag, string msg)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into UserRegLog (ProductID, LicenseKey, IPAddress, CustomerName, Flag, Msg)");
            sb.Append(" values ('");
            sb.Append(regData.ProductID + "', '");
            sb.Append(regData.LicenseKey + "', '");
            sb.Append(regData.IPAddr.ToString() + "', '");
            sb.Append(regData.CustomerName + "', '");
            sb.Append(regFlag + "', '");
			sb.Append(msg + "')");

            using (SqlConnection cn = new SqlConnection(m_ConnStr))
            {
                SqlCommand cmd = new SqlCommand(sb.ToString(), cn);
                cn.Open();
                cmd.ExecuteNonQuery();
                cn.Close();
            }

			string result = null;
			switch (regFlag)
			{
				case RegFlag.Insert:
					result = "新增成功。";
					break;
				case RegFlag.Update:
					result = "更新成功。";
					break;
				case RegFlag.Failed:
					result = "失敗!";
					break;
				case RegFlag.Pirate:
					result = "疑似海盜（有可能是使用者更換 IP）。";
					break;
				default:
					result = "結果未定義（程式有問題）";
					break;
			}

			if (result != null) 
			{
				sb.Length = 0;
				sb.Append("使用者註冊結果通知：");
				sb.Append(result);
				sb.Append("<BR/><BR/>User name:");
				sb.Append(regData.CustomerName);
				sb.Append("<BR/>Product ID: ");
				sb.Append(regData.ProductID);
				sb.Append("<BR/>License key: ");
				sb.Append(regData.LicenseKey);
				sb.Append("<BR/><BR/>註冊時間: ");
				sb.Append(DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss"));
				sb.Append("<BR/>IP 位址: ");
				sb.Append(regData.IPAddr.ToString());
				sb.Append("<BR/>");

				SendAlertMail(AppTitle + "：使用者註冊" + result, sb);
			}
        }

        /// <summary>
        /// 檢查指定的序號是否有效。
        /// </summary>
        /// <param name="licenseKey"></param>
		/// <param name="versionName">版本名稱（輸出參數）。</param>
		/// <param name="expiredDate">有效期限</param>
        /// <returns>若傳回 true，表示序號有效，同時會將此序號所代表的產品版本指定給輸出參數 versionName。</returns>
        private bool IsLicenseKeyValid(string licenseKey, out string versionName, out DateTime expiredDate)
        {
			bool isValid = false;
			versionName = "";
			expiredDate = DateTime.Now.AddDays(-1.0);	// 預設為已過期

            using (SqlConnection cn = new SqlConnection(m_ConnStr))
            {
                // note: 不管是否該序號已經被註冊過（因為 user 可以重複註冊）。
                string sql = "select VersionName, ExpDate from LicenseKeys where KeyValue='" + licenseKey.ToUpper() + "'";
                SqlCommand cmd = new SqlCommand(sql, cn);
                cn.Open();
				SqlDataReader rdr = cmd.ExecuteReader();
				if (rdr.Read())
				{
					versionName = rdr.GetString(0);
					expiredDate = rdr.GetDateTime(1);
					if (DateTime.Now <= expiredDate)
					{
						isValid = true;
					}
				}
                cn.Close();                
            }

			return isValid;
        }

        /// <summary>
        /// 傳回使用者註冊資料。
        /// </summary>
        /// <param name="productId"></param>
        /// <param name="licenseKey"></param>
        /// <returns></returns>
        private UserRegData GetUserRegData(string productId, string licenseKey)
        {
            using (SqlConnection cn = new SqlConnection(m_ConnStr))
            {
                string sql = "select * from UserReg where ProductID='" + productId.ToUpper() +
                    "' and LicenseKey='" + licenseKey.ToUpper() + "'";
                SqlCommand cmd = new SqlCommand(sql, cn);
                cn.Open();
                SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                if (rdr.Read())
                {
                    UserRegData urd = new UserRegData();
                    urd.ProductID = rdr["ProductID"].ToString();
                    urd.LicenseKey = rdr["LicenseKey"].ToString();
					urd.VersionName = rdr["VersionName"].ToString();
                    urd.IPAddr = IPAddress.Parse(rdr["IPAddress"].ToString());
                    urd.CustomerName = rdr["CustomerName"].ToString();
                    urd.ContactName = rdr["ContactName"].ToString();
                    urd.Email = rdr["Email"].ToString();
                    urd.Tel = rdr["Tel"].ToString();
                    urd.Address = rdr["Address"].ToString();
					urd.ExpiredDate = DateTime.Parse(rdr["ExpDate"].ToString());

                    return urd;
                }
                else
                {
                    return null;
                }
            }
        }

		/// <summary>
		/// 檢查指定的 IP 位址是否有註冊。
		/// </summary>
		/// <param name="ip">IP 位址</param>
		/// <param name="onlyClassC">是否只檢查 class C。</param>
		/// <returns></returns>
		private bool IsIPAddressRegistered(string ip, bool onlyClassC)
		{
			if (String.IsNullOrEmpty(ip))
				return false;

			bool isValid = false;

			using (SqlConnection cn = new SqlConnection(m_ConnStr))
			{
				string sql;

				if (onlyClassC)
				{
					int i = ip.LastIndexOf('.');
					ip = ip.Substring(0, i);
					sql = "select count(*) from UserReg where IPAddress like '" + ip + "%'";
				}
				else
				{
					sql = "select count(*) from UserReg where IPAddress = '" + ip + "'";
				}

				SqlCommand cmd = new SqlCommand(sql, cn);
				cn.Open();
				SqlDataReader rdr = cmd.ExecuteReader();
				if (rdr.Read())
				{
					if (rdr.GetInt32(0) > 0)
					{
						isValid = true;
					}
				}
				cn.Close();
			}

			return isValid;
		}

        /// <summary>
        /// 檢查指定的產品編號是否存在。
        /// </summary>
        /// <param name="productID"></param>
        /// <returns></returns>
        private bool ProductExists(string productId)
        {
            using (SqlConnection cn = new SqlConnection(m_ConnStr))
            {
                string sql = "select count(*) from Products where ID='" + productId.ToUpper() + "'";
                SqlCommand cmd = new SqlCommand(sql, cn);
                cn.Open();
                SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                if (rdr.Read())
                {
                    if (rdr.GetInt32(0) > 0)
                    {
                        return true;
                    }
                }
            }
            return false;
        }


        /// <summary>
        /// 將使用者註冊資料解密。
        /// </summary>
        /// <param name="regText"></param>
        /// <returns>使用者註冊資料，各欄位以分號隔開。</returns>
        [WebMethod]
        public string DecryptRegData(string regText)
        {
            UserRegCrypto crypto = new UserRegCrypto();

            UserRegData regData = crypto.DecryptRegData(regText);
            if (regData == null)
            {
                return "";
            }
            else
            {
                return regData.ToString();
            }
        }

		/// <summary>
		/// 新增一筆軟體自動更新的記錄。
		/// </summary>
		/// <param name="userName"></param>
		/// <param name="productName"></param>
		/// <param name="licenseKey"></param>
		/// <param name="productVersion"></param>
		/// <param name="fileVersion"></param>
		[WebMethod]
		public void WriteAutoUpdateLog(string userName, string productName, string licenseKey, 
			string productVersion, string fileVersion)
		{
			string userIP = GetClientIP();

			StringBuilder sb = new StringBuilder();
			sb.Append("insert into UserUpdateLog (CustomerName, IPAddress, ProductName, LicenseKey, ProductVersion, OrgFileVersion)");
			sb.Append(" values ('");
			sb.Append(userName + "', '");
			sb.Append(userIP + "', '");
			sb.Append(productName + "', '");
			sb.Append(licenseKey + "', '");
			sb.Append(productVersion + "', '");
			sb.Append(fileVersion + "')");

			using (SqlConnection cn = new SqlConnection(m_ConnStr))
			{
				SqlCommand cmd = new SqlCommand(sb.ToString(), cn);
				cn.Open();
				cmd.ExecuteNonQuery();
				cn.Close();
			}
		}

		/// <summary>
		/// 測試 E-mail 發送功能是否正常。
		/// </summary>
		/// <param name="receiverEmail"></param>
		[WebMethod]
		public string TestEmail() 
		{
			StringBuilder sb = new StringBuilder();
			sb.Append("看到這封信代表 ProductService.asmx 郵件發送功能正常。");
			try
			{
				SendAlertMail("ProductService.asmx 測試郵件發送功能", sb);
				return "測試郵件已發送至 " + m_AdminEmail;
			}
			catch (Exception ex)
			{
				return ex.Message;
			}
		}
    }
}
