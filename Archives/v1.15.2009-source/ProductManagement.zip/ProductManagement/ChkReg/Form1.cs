﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using Huanlin.AppBlock.Registration;

namespace ChkReg
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void btnGo_Click(object sender, EventArgs e)
		{
			if (!File.Exists(txtFileName.Text)) 
			{
				MessageBox.Show("檔案不存在!");
				return;
			}

			UserRegCrypto crypto = new UserRegCrypto();
			UserRegData regData = crypto.DecryptRegDataFile(txtFileName.Text);
			if (regData == null)
			{
				StreamReader sr = new StreamReader(txtFileName.Text, Encoding.Default);
				txtRegData.Text = "註冊檔無效!\r\n" + sr.ReadToEnd();
				sr.Close();
				sr.Dispose();
			}
			else
			{
				txtRegData.Text = regData.ToString();
			}

		}

		private void btnBrowse_Click(object sender, EventArgs e)
		{
			OpenFileDialog dlg = new OpenFileDialog();
			dlg.FileName = "UserReg.dat";
			if (dlg.ShowDialog() == DialogResult.OK)
			{
				txtFileName.Text = dlg.FileName;
			}
		}
	}
}