﻿namespace ChkReg
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtFileName = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.btnBrowse = new System.Windows.Forms.Button();
			this.btnGo = new System.Windows.Forms.Button();
			this.txtRegData = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// txtFileName
			// 
			this.txtFileName.Location = new System.Drawing.Point(70, 29);
			this.txtFileName.Margin = new System.Windows.Forms.Padding(4);
			this.txtFileName.Name = "txtFileName";
			this.txtFileName.Size = new System.Drawing.Size(397, 25);
			this.txtFileName.TabIndex = 0;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(22, 32);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(41, 15);
			this.label1.TabIndex = 1;
			this.label1.Text = "檔案:";
			// 
			// btnBrowse
			// 
			this.btnBrowse.Location = new System.Drawing.Point(474, 29);
			this.btnBrowse.Name = "btnBrowse";
			this.btnBrowse.Size = new System.Drawing.Size(31, 26);
			this.btnBrowse.TabIndex = 2;
			this.btnBrowse.Text = "...";
			this.btnBrowse.UseVisualStyleBackColor = true;
			this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
			// 
			// btnGo
			// 
			this.btnGo.Location = new System.Drawing.Point(25, 89);
			this.btnGo.Name = "btnGo";
			this.btnGo.Size = new System.Drawing.Size(114, 38);
			this.btnGo.TabIndex = 3;
			this.btnGo.Text = "Go!";
			this.btnGo.UseVisualStyleBackColor = true;
			this.btnGo.Click += new System.EventHandler(this.btnGo_Click);
			// 
			// txtRegData
			// 
			this.txtRegData.Location = new System.Drawing.Point(25, 133);
			this.txtRegData.Multiline = true;
			this.txtRegData.Name = "txtRegData";
			this.txtRegData.Size = new System.Drawing.Size(480, 71);
			this.txtRegData.TabIndex = 4;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(176, 72);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(329, 55);
			this.label2.TabIndex = 5;
			this.label2.Text = "此工具的用途是檢查使用者的註冊檔案是否有效，並顯示解密後的註冊資料。";
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(541, 224);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.txtRegData);
			this.Controls.Add(this.btnGo);
			this.Controls.Add(this.btnBrowse);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.txtFileName);
			this.Font = new System.Drawing.Font("PMingLiU", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
			this.Margin = new System.Windows.Forms.Padding(4);
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "ChkReg (注意! 此工具為開發人員專用!)";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox txtFileName;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btnBrowse;
		private System.Windows.Forms.Button btnGo;
		private System.Windows.Forms.TextBox txtRegData;
		private System.Windows.Forms.Label label2;
	}
}

